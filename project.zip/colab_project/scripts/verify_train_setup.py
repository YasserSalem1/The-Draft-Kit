import sys
import os
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent.resolve()
sys.path.append(str(project_root))

try:
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader
    from src.data.dataset import LoLDraftDataset
    from src.models.transformer import LoLTransformer
    
    print("Imports successful.")
    
    CONFIG = {
        "vocab_path": project_root / "data/metadata/vocab.json",
        "train_path": project_root / "data/processed/train.parquet",
        "d_model": 256,
        "nhead": 8,
        "num_layers": 6,
        "dim_feedforward": 1024,
        "max_seq_len": 150
    }
    
    if not CONFIG["vocab_path"].exists() or not CONFIG["train_path"].exists():
        print("Data not found, skipping dry run.")
        sys.exit(0)
        
    ds = LoLDraftDataset(str(CONFIG["train_path"]), str(CONFIG["vocab_path"]), max_seq_len=CONFIG["max_seq_len"])
    loader = DataLoader(ds, batch_size=2, shuffle=True)
    
    vocab_size = len(ds.vocab)
    model = LoLTransformer(
        vocab_size=vocab_size, 
        d_model=CONFIG["d_model"],
        nhead=CONFIG["nhead"],
        num_encoder_layers=CONFIG["num_layers"],
        num_decoder_layers=CONFIG["num_layers"],
        dim_feedforward=CONFIG["dim_feedforward"]
    )
    
    print("Model initialized.")
    batch = next(iter(loader))
    src = batch['input_tokens']
    tgt = batch['target_tokens']
    
    tgt_input = tgt[:, :-1]
    logits = model(src, tgt_input)
    
    print(f"Forward pass successful. Shape: {logits.shape}")
    print("Setup Verification Passed.")
    
except Exception as e:
    print(f"Setup Failed: {e}")
    sys.exit(1)
