import sys
import torch
import json
import argparse
import random
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# Add project root to sys.path
current_dir = Path(__file__).parent
project_root = current_dir.parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from AI.src.data.dataset import LoLTokenizer, LoLDraftDataset
from AI.src.models.transformer import LoLTransformer

console = Console()

# Standard Draft Order
DRAFT_ORDER = [
    # Phase 1 Bans
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    # Phase 1 Picks
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    # Phase 2 Bans
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    # Phase 2 Picks
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
]

def constrained_greedy_decode(model, src, max_len, start_idx, end_idx, device, tokenizer, draft_order):
    model.eval()
    tgt = torch.full((1, 1), start_idx, dtype=torch.long, device=device)
    
    # Pre-identify structure tokens for faster filtering
    structure_tokens = set()
    for t, idx in tokenizer.vocab.items():
        if t.startswith("STEP_") or t.endswith("_BAN") or t.endswith("_PICK") or t.startswith("["):
            structure_tokens.add(idx)

    # Initial Context from Source
    # src is [1, Seq]
    history_ids = src[0].tolist()
    
    for _ in range(max_len):
        with torch.no_grad():
            output = model(src, tgt)
            next_token_logits = output[:, -1, :]
            
            # --- CONSTRAINED DECODING ---
            
            # 1. Parse Current State
            # Combine history + generated
            current_generated = tgt[0].tolist()
            # Sequence reconstruction
            # We treat src + tgt[1:] as the full timeline (assuming src starts with START)
            # CAUTION: In predict.py main(), src = item['input_tokens']. Item input tokens include START.
            # So src[0] is START...
            full_ids = history_ids + current_generated[1:]
            
            used_champions = set()
            current_step_num = 0
            current_phase = "START" # START, STEP, ACTION, CHAMPION
            
            # Parse tokens
            for idx in full_ids:
                if idx in [tokenizer.start_idx, tokenizer.pad_idx, tokenizer.sep_idx, tokenizer.end_idx]:
                    continue
                
                token = tokenizer.id_to_token.get(idx, "")
                
                if token.startswith("STEP_"):
                    current_step_num = int(token.replace("STEP_", ""))
                    current_phase = "STEP"
                elif "_BAN" in token or "_PICK" in token:
                    current_phase = "ACTION"
                else:
                    # Champion
                    current_phase = "CHAMPION"
                    used_champions.add(token)

            # 2. Determine Valid Next Tokens
            valid_tokens = []
            allowed_indices = []
            
            # Logic Transition
            if current_phase == "START" or current_phase == "CHAMPION":
                # Next is STEP_{N+1}
                next_step = current_step_num + 1
                if next_step <= len(draft_order):
                    valid_tokens = [f"STEP_{next_step}"]
                else:
                    allowed_indices = [end_idx] # Draft Over
            
            elif current_phase == "STEP":
                # Next is ACTION for this step
                if 0 <= current_step_num - 1 < len(draft_order):
                    rule = draft_order[current_step_num - 1]
                    action_token = f"{rule['side']}_{rule['action']}"
                    valid_tokens = [action_token]
                else:
                    allowed_indices = [end_idx]

            elif current_phase == "ACTION":
                # Next is CHAMPION
                pass

            # 3. Apply Mask
            mask = torch.full_like(next_token_logits, float('-inf'))
            
            if current_phase == "ACTION":
                # "Open" set case: Allow all champions except used
                mask = next_token_logits.clone()
                
                # Mask out structure/special tokens
                for s_idx in structure_tokens:
                    mask[0, s_idx] = float('-inf')
                    
                # Mask out used champions
                for champ in used_champions:
                    if champ in tokenizer.vocab:
                        mask[0, tokenizer.vocab[champ]] = float('-inf')
                        
            else:
                # "Closed" set case
                if not valid_tokens and not allowed_indices:
                     allowed_indices = [end_idx]

                for vt in valid_tokens:
                    if vt in tokenizer.vocab:
                        allowed_indices.append(tokenizer.vocab[vt])
                
                if not allowed_indices:
                     allowed_indices = [end_idx]
                
                tensor_indices = torch.tensor(allowed_indices, device=device)
                mask.index_copy_(1, tensor_indices, next_token_logits.index_select(1, tensor_indices))

            # --- END CONSTRAINTS ---

            next_token = mask.argmax(dim=-1)
            
            if next_token.item() == end_idx:
                break
            
            tgt = torch.cat([tgt, next_token.unsqueeze(0)], dim=1)
            
    return tgt[0].tolist()

def decode_sequence(ids, vocab_inv):
    tokens = []
    for idx in ids:
        token = vocab_inv.get(idx, "[UNK]")
        if token in ["[PAD]", "[START]", "[END]", "[SEP]"]:
            continue
        tokens.append(token)
    return tokens

def format_comparison(input_tokens, truth_tokens, pred_tokens):
    # Determine the context (last 10 steps of input)
    context = input_tokens[-10:] if len(input_tokens) > 10 else input_tokens
    
    # Create Layout
    console.print(Panel("\n".join(context), title="Input Context (Last steps)", style="blue"))
    
    # Side by side comparison
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Ground Truth (What actually happened)", style="green")
    table.add_column("Model Prediction", style="yellow")
    
    max_len = max(len(truth_tokens), len(pred_tokens))
    for i in range(max_len):
        t = truth_tokens[i] if i < len(truth_tokens) else ""
        p = pred_tokens[i] if i < len(pred_tokens) else ""
        table.add_row(t, p)
        
    console.print(table)
    console.print("-" * 50)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/train.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--samples", type=int, default=3)
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    # Load Tokenizer & Dataset
    try:
        # We only need validation dataset really, but train is fine for check
        ds = LoLDraftDataset(args.data, args.vocab)
        tokenizer = ds.tokenizer
    except Exception as e:
        console.print(f"[red]Error loading data/tokenizer:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    console.print(f"Loading model on {device}...")
    
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
        console.print("[green]Model loaded successfully.[/green]")
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Run Inference on Random Samples
    indices = random.sample(range(len(ds)), args.samples)
    
    for idx in indices:
        item = ds[idx]
        console.print(f"\n[bold]Sample {idx}[/bold]")
        
        # Prepare Input
        src = item['input_tokens'].unsqueeze(0).to(device) # [1, Seq]
        
        # Ground Truth
        tgt_ids = item['target_tokens'].tolist()
        truth_tokens = decode_sequence(tgt_ids, tokenizer.id_to_token)
        
        # Input History for Context
        src_ids = item['input_tokens'].tolist()
        input_tokens = decode_sequence(src_ids, tokenizer.id_to_token)
        
        # Prediction
        pred_ids = constrained_greedy_decode(
            model, src, max_len=60, 
            start_idx=tokenizer.start_idx, end_idx=tokenizer.end_idx, 
            device=device,
            tokenizer=tokenizer,
            draft_order=DRAFT_ORDER
        )
        pred_tokens = decode_sequence(pred_ids, tokenizer.id_to_token)
        
        format_comparison(input_tokens, truth_tokens, pred_tokens)

if __name__ == "__main__":
    main()
