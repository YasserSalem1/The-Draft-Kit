import json
import torch
import pandas as pd
import numpy as np
from pathlib import Path
from torch.utils.data import Dataset
from typing import Dict, List, Tuple, Any, Optional

class LoLDraftDataset(Dataset):
    """
    PyTorch Dataset for League of Legends Drafts.
    Encoder Input: Draft History
    Decoder Target: Remaining Sequence
    """
    def __init__(
        self, 
        parquet_path: str, 
        vocab_path: str, 
        max_seq_len: int = 150
    ):
        self.parquet_path = Path(parquet_path)
        self.vocab_path = Path(vocab_path)
        self.max_seq_len = max_seq_len
        
        # Load Vocabulary
        if not self.vocab_path.exists():
            raise FileNotFoundError(f"Vocab file not found at {self.vocab_path}")
            
        with open(self.vocab_path, 'r', encoding='utf-8') as f:
            self.vocab = json.load(f)
            
        self.id_to_token = {v: k for k, v in self.vocab.items()}
        
        # Verify Special Tokens exist
        required_tokens = ["[PAD]", "[START]", "[END]", "[SEP]"]
        for t in required_tokens:
            if t not in self.vocab:
                raise ValueError(f"Vocabulary missing required token: {t}")
                
        self.pad_idx = self.vocab["[PAD]"]
        self.start_idx = self.vocab["[START]"]
        self.end_idx = self.vocab["[END]"]
        self.sep_idx = self.vocab["[SEP]"]
        
        # Load Data
        if not self.parquet_path.exists():
            raise FileNotFoundError(f"Data file not found at {self.parquet_path}")
            
        # We read the whole dataframe into memory. 
        # For 150k rows this is fine (~few hundred MBs). 
        # For larger datasets, use memory mapping or chunking.
        self.data = pd.read_parquet(self.parquet_path)
        
    def __len__(self):
        return len(self.data)
        
    def _tokenize_dict_list(self, step_list: List[Dict[str, Any]]) -> List[int]:
        """
        Converts a list of draft steps (dicts) into a list of token IDs.
        Format per step: [STEP_X, ACTION, CHAMPION]
        """
        tokens = []
        for step_data in step_list:
            # 1. Step Token
            step_num = step_data.get("step")
            step_token = f"STEP_{step_num}"
            
            # 2. Action Token
            # Construct ACTION (e.g. BLUE_BAN, RED_PICK)
            team = step_data.get("team")
            # If team is not explicit (raw data uses banned_by_team/played_by_team), handle it?
            # Preprocess.py just dumps the raw dict info.
            # Raw data snippet: "banned_by_team": "DRX", "teams": {"BLUE": "DRX"...}
            # Wait, `step_data` in raw json DOES NOT have "team" or "action" keys directly!
            # It has "banned_by_team", "played_by_team".
            # AND "step" is "1", "2"...
            # I need to infer ACTION (BLUE_BAN etc) from the step number or other fields?
            # Actually, standard LoL draft order is fixed.
            # Bans: 1-6 (Blue, Red, Blue, Red, Blue, Red) -> Steps 1-6
            # Picks: 7-12 (Blue, Red, Red, Blue, Blue, Red) -> Steps 7-12
            # Bans: 13-16 (Red, Blue, Red, Blue) -> Steps 13-16
            # Picks: 17-20 (Red, Blue, Blue, Red) -> Steps 17-20
            # BUT the raw data *does* have "side_to_act" at match level, but steps?
            # Looking at raw data: Step 1: "banned_by_team": "DRX". Match "teams": {"BLUE": "DRX"}. So BLUE ban.
            # Step 7: "played_by_team": "DRX".
            
            # Helper to deduce side and type
            # We need to map team name to BLUE/RED. But we assume `step_data` is just the inner dict.
            # CRITICAL: accessing 'teams' mapping from within the step is hard if we just have step list.
            # However, usually dataset assumes valid tokens are constructible.
            # If I cannot deduce BLUE/RED from just the step dict without context, I might be in trouble.
            # BUT: In standardized draft (Fearless), steps 1-20 have fixed sides.
            # Let's rely on Step Number for Action Type/Side if possible, OR
            # The previous preprocessing/data loading might have added "team" and "action"?
            # NO, `preprocess.py` just dumps raw `draft` list.
            # I need to determine Action Token logic.
            
            # Fixed Order for Professional Draft (10 Bans):
            # 1: BB1, 2: RB1, 3: BB2, 4: RB2, 5: BB3, 6: RB3
            # 7: BP1, 8: RP1, 9: RP2, 10: BP2, 11: BP3, 12: RP3
            # 13: RB4, 14: BB4, 15: RB5, 16: BB5
            # 17: RP4, 18: BP4, 19: BP5, 20: RP5
            
            s = int(step_num)
            if s in [1, 3, 5, 14, 16]: side, type_ = "BLUE", "BAN"
            elif s in [2, 4, 6, 13, 15]: side, type_ = "RED", "BAN"
            elif s in [7, 10, 11, 18, 19]: side, type_ = "BLUE", "PICK"
            elif s in [8, 9, 12, 17, 20]: side, type_ = "RED", "PICK"
            else: side, type_ = "BLUE", "UNKNOWN" # Should not happen
            
            action_token = f"{side}_{type_}"

            # 3. Role Token
            # For bans, role is usually unknown or irrelevant, but we include it.
            role = step_data.get("role", step_data.get("primary_role", "UNKNOWN"))
            if role is None: role = "UNKNOWN"
            role_token = f"ROLE_{role}"

            # 4. Champion Token
            champion = step_data.get("champion")
            
            # 5. Class Tokens
            classes = step_data.get("champion_class", [])
            class_tokens = [f"CLASS_{c}" for c in classes]
            
            # Lookup and Append
            if step_token not in self.vocab:
                 # Default handling or error
                 raise ValueError(f"Unknown step token: {step_token}")
            
            # Action token check
            if action_token not in self.vocab:
                 raise ValueError(f"Unknown action token: {action_token}")
                 
            # Role token check
            if role_token not in self.vocab:
                 # Fallback to ROLE_UNKNOWN if not found?
                 # If "UNKNOWN" is in vocab, use it.
                 if "ROLE_UNKNOWN" in self.vocab:
                     role_token = "ROLE_UNKNOWN"
                 else:
                     raise ValueError(f"Unknown role token: {role_token}")

            if champion not in self.vocab:
                 raise ValueError(f"Unknown champion token: {champion}")
                 
            # Build list: Step, Action, Role, Champ, [Classes...]
            step_tokens_ids = [
                self.vocab[step_token],
                self.vocab[action_token],
                self.vocab[role_token],
                self.vocab[champion]
            ]
            
            for ct in class_tokens:
                if ct in self.vocab:
                    step_tokens_ids.append(self.vocab[ct])
                # Else ignore? Or error? Ignore is safer for weird classes.
            
            tokens.extend(step_tokens_ids)
            
        return tokens

    def __getitem__(self, idx) -> Dict[str, torch.Tensor]:
        row = self.data.iloc[idx]
        
        # Parse JSON
        draft_history = json.loads(row['draft_history'])
        remaining_sequence = json.loads(row['remaining_sequence'])
        
        # Tokenize (No [START]/[END] added inside helper)
        history_ids = self._tokenize_dict_list(draft_history)
        remaining_ids = self._tokenize_dict_list(remaining_sequence)
        
        # Construct Input (Encoder)
        # Format: [START] ... history ... [SEP] (Optional, depends on preference, usually just history)
        # Let's do: [START] H0, H1...
        input_ids = [self.start_idx] + history_ids
        
        # Construct Target (Decoder)
        # Format: [START] ... remaining ... [END]
        target_ids = [self.start_idx] + remaining_ids + [self.end_idx]
        
        # Truncate if necessary (Unlikely given 20 steps * 3 tokens = 60 tokens << 150)
        if len(input_ids) > self.max_seq_len:
            input_ids = input_ids[-self.max_seq_len:] # Keep most recent history
            # Ensure index 0 is start? If we truncate history, we lose start.
            # Usually better to truncate from beginning but keep START.
            # But with len=60, this won't happen.
            pass

        if len(target_ids) > self.max_seq_len:
            target_ids = target_ids[:self.max_seq_len] # Truncate end of future
            
        # PADDING
        input_len = len(input_ids)
        target_len = len(target_ids)
        
        pad_input_len = self.max_seq_len - input_len
        pad_target_len = self.max_seq_len - target_len
        
        # Create Tensors
        input_tensor = torch.tensor(input_ids + [self.pad_idx] * pad_input_len, dtype=torch.long)
        target_tensor = torch.tensor(target_ids + [self.pad_idx] * pad_target_len, dtype=torch.long)
        
        # Create Masks (1 for valid, 0 for pad)
        input_mask = torch.tensor([1] * input_len + [0] * pad_input_len, dtype=torch.long)
        target_mask = torch.tensor([1] * target_len + [0] * pad_target_len, dtype=torch.long)
        
        return {
            "input_tokens": input_tensor,
            "target_tokens": target_tensor,
            "input_mask": input_mask,
            "target_mask": target_mask,
            # Metadata for debugging
            "match_id": row['match_id'],
            "sample_id": row['sample_id']
        }

if __name__ == "__main__":
    # Self-test block
    import sys
    
    print("Testing LoLDraftDataset...")
    data_path = Path("data/processed/train.parquet")
    vocab_path = Path("data/metadata/vocab.json")
    
    if not data_path.exists() or not vocab_path.exists():
        print("Data or Vocab not found, skipping test.")
    else:
        ds = LoLDraftDataset(data_path, vocab_path)
        print(f"Dataset size: {len(ds)}")
        
        item = ds[0]
        print("\nSample 0:")
        print(f"Input Shape: {item['input_tokens'].shape}")
        print(f"Target Shape: {item['target_tokens'].shape}")
        print(f"Input Mask Sum: {item['input_mask'].sum().item()}")
        
        # Decode input tokens to verify
        # [START] Step X...
        ids = item['input_tokens'].tolist()
        tokens = [ds.id_to_token[i] for i in ids if i != ds.pad_idx]
        print(f"Decoded Input: {tokens}")
