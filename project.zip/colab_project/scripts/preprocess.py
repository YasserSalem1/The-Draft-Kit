import json
import argparse
import sys
import random
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
from typing import List, Dict, Any

def preprocess_data(input_path: Path, output_dir: Path, seed: int = 42):
    """
    Preprocesses raw match data into Expanded training samples (teacher forcing).
    Splits by Match ID to prevent leakage.
    """
    if not input_path.exists():
        print(f"Error: Input file {input_path} not found.")
        sys.exit(1)

    print(f"Loading data from {input_path}...")
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error loading JSON: {e}")
        sys.exit(1)

    # 1. Shuffle & Split by Match ID
    random.seed(seed)
    
    # Pre-process: Correct the sorting of drafts in MEMORY first
    # The raw JSON has lexicographically sorted steps ("1", "10", "2"...)
    # We must fix this to numerical sort (1, 2, 3... 9, 10...)
    print("Fixing draft sort order...")
    print("Fixing draft sort order...")
    for idx, m in enumerate(data):
        m['match_id'] = m.get('match_id', f"match_{idx}")
        draft = m.get('draft') or m.get('current_draft', [])
        # Standardization: Ensure we use 'draft' key going forward in memory
        m['draft'] = draft
        # Sort in-place by integer step
        try:
            draft.sort(key=lambda x: int(x.get('step', -1)))
        except:
            pass # If fail, validation will catch it later
            
    def is_valid_draft(match_data):
        draft = match_data.get('draft', [])
        if len(draft) != 20:
            return False
            
        # Strict Check: Steps must be 1 to 20 in order
        try:
            steps = [int(d.get('step', -1)) for d in draft]
        except (ValueError, TypeError):
            return False
            
        expected = list(range(1, 21))
        is_valid = (steps == expected)
        
        # Debug Print should be rare now
        if not is_valid and random.random() < 0.0001: 
             print(f"DEBUG FAIL: Match {match_data.get('match_id')} Steps: {steps}")

        return is_valid

    # Filter out invalid matches
    valid_data = [m for m in data if is_valid_draft(m)]
    total_valid = len(valid_data)
    print(f"Total valid matches (20 steps, sequential 1-20): {total_valid}")
    
    # Shuffle matches
    random.shuffle(valid_data)
    
    # Clean split indices
    train_end = int(total_valid * 0.8)
    val_end = int(total_valid * 0.9)
    # Test takes the rest (10%)
    
    train_matches = valid_data[:train_end]
    val_matches = valid_data[train_end:val_end]
    test_matches = valid_data[val_end:]
    
    print(f"\nSplit Sizes (Matches):")
    print(f"  Train: {len(train_matches)}")
    print(f"  Val:   {len(val_matches)}")
    print(f"  Test:  {len(test_matches)}")
    
    # 2. Expand Matches into Samples
    def expand_matches(matches: List[Dict]) -> pd.DataFrame:
        samples = []
        for match in matches:
            match_id = match['match_id']
            draft = match['draft']
            fearless = match.get('fearless_removed', [])
            outcome = match.get('outcome', 'UNKNOWN')
            
            # We want to predict step k given steps 0..k-1
            # A full draft has 20 steps (indices 0 to 19).
            # We enable prediction for steps 1 to 19 (predicting the 2nd action through the 20th).
            # Step 0 (first ban) has no history, but usually we just start predicting from step 1?
            # User request: "Expand each match into 19 training samples"
            # If we have 20 steps, we can predict steps 1..19 given previous context.
            # Sample 0: Input=[] -> Target=Step[0]? Or Input=[Step0] -> Target=Step[1]?
            # Let's interpret "Expand into 19 samples":
            # Match has steps S0, S1, ... S19.
            # 1. Given S0, predict S1...
            # ...
            # 19. Given S0..S18, predict S19.
            # This counts as 19 transitions.
            # (Note: Predicting S0 from nothing is usually implicit or handled as "start" state, 
            # but user specifically asked for "Expand each match into 19 samples".
            # If we predict S0, we have 20 samples. If we assume S0 is given (blue ban 1 always starts?), 
            # then 19 predictions. Let's do 0->1, 1->2 ... 18->19.
            
            for k in range(1, 20):
                # History: Steps 0 to k-1
                history_steps = draft[:k]
                
                # Remaining: Steps k to end (The sequence to be predicted/completed)
                # Usually for transformer training (seq2seq), we feed (Encoder=History, Decoder=Target Full Sequence or Next Token)
                # "remaining_sequence" implies the ground truth future for teacher forcing.
                remaining_steps = draft[k:] 
                
                sample = {
                    "match_id": match_id,
                    "sample_id": f"{match_id}_{k}", # Unique ID
                    "current_step": k, # The step index we are ABOUT to take (or the length of history)
                    "draft_history": json.dumps(history_steps),
                    "remaining_sequence": json.dumps(remaining_steps),
                    "fearless_removed": fearless, # List of strings - parquet handles lists well
                    "outcome": outcome
                }
                samples.append(sample)
        
        return pd.DataFrame(samples)

    print("\nExpanding samples...")
    train_df = expand_matches(train_matches)
    val_df = expand_matches(val_matches)
    test_df = expand_matches(test_matches)
    
    print(f"\nExpanded Sample Counts:")
    print(f"  Train: {len(train_df)}")
    print(f"  Val:   {len(val_df)}")
    print(f"  Test:  {len(test_df)}")
    
    # 3. Save to Parquet
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Schema check/enforcement handled by pandas->pyarrow conversion mostly, 
    # but explicit schema can be nice. Default usually works for basic types.
    # Note on 'fearless_removed': pandas default for list column is object. 
    # PyArrow handles it as List<String>.
    
    train_path = output_dir / "train.parquet"
    val_path = output_dir / "val.parquet"
    test_path = output_dir / "test.parquet"
    
    print(f"\nSaving parquet files to {output_dir}...")
    train_df.to_parquet(train_path, index=False)
    val_df.to_parquet(val_path, index=False)
    test_df.to_parquet(test_path, index=False)
    
    # 4. Leakage & Sanity Check
    print("\nRunning Sanity Checks...")
    
    # Load back strictly match_ids
    t_ids = set(pd.read_parquet(train_path, columns=['match_id'])['match_id'])
    v_ids = set(pd.read_parquet(val_path, columns=['match_id'])['match_id'])
    test_ids = set(pd.read_parquet(test_path, columns=['match_id'])['match_id'])
    
    print(f"  Unique Match IDs in Train: {len(t_ids)}")
    print(f"  Unique Match IDs in Val:   {len(v_ids)}")
    print(f"  Unique Match IDs in Test:  {len(test_ids)}")
    
    leakage_tv = t_ids.intersection(v_ids)
    leakage_tt = t_ids.intersection(test_ids)
    leakage_vt = v_ids.intersection(test_ids)
    
    if leakage_tv or leakage_tt or leakage_vt:
        print("[CRITICAL ERROR] Data Leakage Detected!")
        print(f"  Train/Val Leakage: {len(leakage_tv)}")
        print(f"  Train/Test Leakage: {len(leakage_tt)}")
        print(f"  Val/Test Leakage: {len(leakage_vt)}")
        sys.exit(1)
    else:
        print("  [PASS] No Match ID leakage detected between splits.")
        
    print("\nPreprocessing Complete.")

def main():
    parser = argparse.ArgumentParser(description="Preprocess LoL Draft Data into Parquet.")
    parser.add_argument("--input", default="data/raw/all_games.json", help="Path to raw JSON")
    parser.add_argument("--output_dir", default="data/processed", help="Path to output directory")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for splitting")
    
    args = parser.parse_args()
    
    preprocess_data(Path(args.input), Path(args.output_dir), args.seed)

if __name__ == "__main__":
    main()
