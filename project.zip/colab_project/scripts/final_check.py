import os
import sys
from pathlib import Path

def check_file(path, description):
    if os.path.exists(path):
        print(f"[OK] {description} found at {path}")
        return True
    else:
        print(f"[MISSING] {description} NOT found at {path}")
        return False

def main():
    print("=== Final Sanity Checklist ===\n")
    
    checks = [
        ("data/raw/all_games.json", "Raw Data"),
        ("data/metadata/vocab.json", "Vocabulary"),
        ("data/processed/train.parquet", "Train Data"),
        ("data/processed/val.parquet", "Val Data"),
        ("data/processed/test.parquet", "Test Data"),
        ("scripts/validate_raw_data.py", "Validation Script"),
        ("scripts/generate_vocab.py", "Vocab Script"),
        ("scripts/preprocess.py", "Preprocessing Script"),
        ("scripts/verify_parquet.py", "Verify Parquet Script"),
        ("scripts/dataset.py", "Dataset Script"),
        ("scripts/model.py", "Model Script"),
        ("scripts/train.py", "Training Script"),
        ("scripts/evaluate.py", "Evaluation Script"),
        ("scripts/predict.py", "Prediction Script"),
        ("notebooks/train.ipynb", "Training Notebook"),
    ]
    
    all_passed = True
    for path, desc in checks:
        if not check_file(path, desc):
            all_passed = False
            
    if all_passed:
        print("\n[SUCCESS] All file checks passed.")
    else:
        print("\n[FAILURE] Some files are missing.")
        sys.exit(1)
        
    # Verify Model Loading (Integration Check)
    print("\nVerifying Model Loading...")
    try:
        sys.path.append(os.getcwd())
        from scripts.model import LoLTransformer
        model = LoLTransformer(vocab_size=200)
        print("[OK] LoLTransformer instantiated successfully.")
    except Exception as e:
        print(f"[FAIL] Model instantiation failed: {e}")
        sys.exit(1)
        
    print("\n[READY] Environment is fully prepared for training.")

if __name__ == "__main__":
    main()
