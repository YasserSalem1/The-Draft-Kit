import argparse
import sys
import json
import pandas as pd
from pathlib import Path

def verify_split(file_path: Path, split_name: str) -> set:
    """
    Verifies a single parquet split.
    Returns the set of match_ids found in this split.
    """
    if not file_path.exists():
        print(f"Error: {split_name} file not found at {file_path}")
        sys.exit(1)
        
    print(f"\nVerifying {split_name} split ({file_path})...")
    
    try:
        df = pd.read_parquet(file_path)
    except Exception as e:
        print(f"Error reading parquet file: {e}")
        sys.exit(1)
        
    print(f"  Rows: {len(df)}")
    print(f"  Columns: {df.columns.tolist()}")
    
    # 1. Check for missing columns
    required_cols = {'match_id', 'sample_id', 'current_step', 'draft_history', 'remaining_sequence', 'fearless_removed'}
    missing = required_cols - set(df.columns)
    if missing:
        print(f"Error: Missing columns in {split_name}: {missing}")
        sys.exit(1)
        
    # 2. Verify JSON parseability (Sampling or Full Pass)
    # Full pass is safer to guarantee integrity
    print("  Validating JSON fields...")
    try:
        # Vectorized JSON validation is hard, so we apply likely on the first few thousand or all if small enough. 
        # With 150k rows, a simple apply might take a few seconds, which is acceptable for a verification script.
        
        # Check draft_history
        df['draft_history'].apply(json.loads)
        # Check remaining_sequence
        df['remaining_sequence'].apply(json.loads)
    except Exception as e:
        print(f"Error parsing JSON in {split_name}: {e}")
        sys.exit(1)
        
    # 3. Print one example
    print(f"\n[{split_name.upper()} EXAMPLE SAMPLE]")
    try:
        sample = df.iloc[0]
        print(f"  Match ID: {sample['match_id']}")
        print(f"  Sample ID: {sample['sample_id']}")
        print(f"  Current Step: {sample['current_step']}")
        print(f"  Draft History (First 2): {json.loads(sample['draft_history'])[:2]}")
        print(f"  Remaining (First 2): {json.loads(sample['remaining_sequence'])[:2]}")
        print(f"  Fearless Removed: {sample['fearless_removed']}")
    except Exception as e:
        print(f"Error printing example: {e}")
        
    return set(df['match_id'].unique())

def main():
    parser = argparse.ArgumentParser(description="Verify processed Parquet files.")
    parser.add_argument("--data_dir", default="data/processed", help="Path to processed data directory")
    args = parser.parse_args()
    
    data_dir = Path(args.data_dir)
    
    train_ids = verify_split(data_dir / "train.parquet", "train")
    val_ids = verify_split(data_dir / "val.parquet", "val")
    test_ids = verify_split(data_dir / "test.parquet", "test")
    
    print("\nChecking for Data Leakage (Match Overlaps)...")
    
    leakage_tv = train_ids.intersection(val_ids)
    leakage_tt = train_ids.intersection(test_ids)
    leakage_vt = val_ids.intersection(test_ids)
    
    has_error = False
    
    if leakage_tv:
        print(f"Error: {len(leakage_tv)} overlapping matches between TRAIN and VAL.")
        has_error = True
        
    if leakage_tt:
        print(f"Error: {len(leakage_tt)} overlapping matches between TRAIN and TEST.")
        has_error = True
        
    if leakage_vt:
        print(f"Error: {len(leakage_vt)} overlapping matches between VAL and TEST.")
        has_error = True
        
    if has_error:
        print("Verification FAILED due to data leakage.")
        sys.exit(1)
    else:
        print("\nSUCCESS: All parquet files verified and no data leakage detected.")
        sys.exit(0)

if __name__ == "__main__":
    main()
