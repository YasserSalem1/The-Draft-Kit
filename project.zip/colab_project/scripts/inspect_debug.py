import pandas as pd
import json
import sys
from pathlib import Path

# Add project root to sys.path
current_dir = Path(__file__).parent
project_root = current_dir.parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from AI.src.data.dataset import LoLTokenizer

def inspect_sample():
    df = pd.read_parquet("AI/data/processed/train.parquet")
    # Finding sample 13377
    # Note: 'indices = random.sample(range(len(ds)), args.samples)' in predict.py usage implies index 13377 is the integer index, not ID.
    
    # We need to load the dataset effectively to get the same index
    # But usually index matches row number if no shuffling.
    # Let's inspect row 13377
    
    print(f"Total rows: {len(df)}")
    
    # Check row 13377
    try:
        row = df.iloc[13377]
        print(f"--- Row 13377 ---")
        print(f"Match ID: {row['match_id']}")
        print(f"Draft History Raw: {row['draft_history']}")
        
        history = json.loads(row['draft_history'])
        print(f"Parsed History Steps: {[s['step'] for s in history]}")
        
    except IndexError:
        print("Index 13377 out of bounds")

if __name__ == "__main__":
    inspect_sample()
