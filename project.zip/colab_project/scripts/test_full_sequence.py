import sys
import torch
import json
import argparse
import random
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# Add project root to sys.path
current_dir = Path(__file__).parent
project_root = current_dir.parent.parent
if str(project_root) not in sys.path:
    sys.path.append(str(project_root))

from AI.src.data.dataset import LoLTokenizer, LoLDraftDataset
from AI.src.models.transformer import LoLTransformer

console = Console()

def decode_and_parse(ids, tokenizer):
    steps = []
    current = {}
    
    tokens = [tokenizer.id_to_token[i] for i in ids if i not in [tokenizer.pad_idx, tokenizer.start_idx, tokenizer.end_idx]]
    
    for t in tokens:
        if t.startswith("STEP_"):
            if "step" in current and "champion" in current:
                steps.append(current)
            try:
                step_num = int(t.replace("STEP_", ""))
            except:
                step_num = 0
            current = {"step": step_num}
        elif "_PICK" in t or "_BAN" in t:
            parts = t.split("_")
            current["team"] = parts[0]
            current["action"] = parts[1]
        else:
            current["champion"] = t
            
    if "step" in current and "champion" in current:
        steps.append(current)
        
    return steps

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/train.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--index", type=int, default=0) # Specific index to test
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    # Load Dataset
    try:
        # augment=False to see raw sorted data without random cuts for now
        ds = LoLDraftDataset(args.data, args.vocab, augment=False)
    except Exception as e:
        console.print(f"[red]Error loading data:[/red] {e}")
        return

    # Pick a sample
    # We want a sample that represents a full sequence for verification
    # But dataset returns Input + Target based on internal logic.
    # To see FULL sequence 1-20, we should look at raw data manually or reconstruct.
    # ds[idx] gives input (history) and target (remaining).
    # Since augment=False, it splits at a fixed point? 
    # Wait, dataset `__getitem__` logic:
    # default (augment=False): loads draft_history and remaining_sequence from parquet columns.
    # IN PARQUET, are they full split?
    # Usually `draft_history` and `remaining_sequence` in `train_processed` are pre-split snapshots?
    # If so, iterating rows will give different snapshots.
    # But my fix in dataset.py sorts them.
    
    idx = args.index
    item = ds[idx]
    
    console.print(f"[bold cyan]Checking Sample {idx} from Dataset (Ground Truth)[/bold cyan]")
    
    # helper
    def sequence_to_table(seq, title):
        table = Table(title=title)
        table.add_column("Step", justify="right", style="cyan")
        table.add_column("Team", style="bold")
        table.add_column("Action", style="dim")
        table.add_column("Champion", style="bold green")
        
        # Sort just in case, but we want to verify dataset order
        # seq.sort(key=lambda x: x['step']) 
        
        for s in seq:
            table.add_row(
                str(s.get('step', '?')),
                s.get('team', ''),
                s.get('action', ''),
                s.get('champion', '')
            )
        return table

    # 1. GROUND TRUTH (What the dataset feeds the model)
    input_ids = item['input_tokens'].tolist()
    target_ids = item['target_tokens'].tolist()
    
    input_steps = decode_and_parse(input_ids, ds.tokenizer)
    target_steps = decode_and_parse(target_ids, ds.tokenizer)
    
    # Combine to show FULL Ground Truth
    full_gt = input_steps + target_steps
    # If my dataset fix works, this list should be 1..20 sorted.
    
    console.print(sequence_to_table(full_gt, "Full Ground Truth Sequence (Dataset)"))
    
    # Check strict ordering
    steps = [s['step'] for s in full_gt]
    console.print(f"\n[bold]Step Order Found:[/bold] {steps}")
    
    expected = list(range(1, len(steps) + 1))
    # Note: Dataset might start at step X if history is partial.
    # But usually samples cover the draft.
    # If steps are [1, 2, 3... 20] -> PASS.
    
    if steps == sorted(steps):
        console.print("[bold green]✅ PASS: Data is strictly increasing![/bold green]")
    else:
        console.print("[bold red]❌ FAIL: Data is NOT sorted![/bold red]")

    # 2. MODEL PREDICTION (Optional, to show current broken state)
    # Load Model
    device = torch.device(args.device)
    if Path(args.checkpoint).exists():
        model = LoLTransformer(
            vocab_size=len(ds.vocab),
            d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
            dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=ds.pad_idx
        ).to(device)
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
        model.eval()

        # Run inference given input
        src = item['input_tokens'].unsqueeze(0).to(device)
        # Greedy decode
        tgt_in = torch.full((1, 1), ds.start_idx, dtype=torch.long, device=device)
        for _ in range(60):
            with torch.no_grad():
                out = model(src, tgt_in)
                next_token = out[:, -1, :].argmax(dim=-1)
                if next_token.item() == ds.end_idx:
                    break
                tgt_in = torch.cat([tgt_in, next_token.unsqueeze(0)], dim=1)
        
        pred_ids = tgt_in[0].tolist()
        pred_steps = decode_and_parse(pred_ids, ds.tokenizer)
        
        console.print(sequence_to_table(pred_steps, "Current Model Prediction (Before Retraining)"))
    else:
        console.print("[yellow]Checkpoint not found, skipping prediction check.[/yellow]")

if __name__ == "__main__":
    main()
