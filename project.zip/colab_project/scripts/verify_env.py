import sys
import os

def check_import(module_name):
    try:
        __import__(module_name)
        print(f"[OK] {module_name} imported successfully.")
        return True
    except ImportError as e:
        print(f"[FAIL] Could not import {module_name}: {e}")
        return False

def main():
    print(f"Python executable: {sys.executable}")
    
    checks = [
        "ipykernel",
        "torch",
        "numpy",
        "pandas"
    ]
    
    all_passed = True
    for module in checks:
        if not check_import(module):
            all_passed = False
            
    if all_passed:
        print("\nAll checks passed! The environment is ready.")
        sys.exit(0)
    else:
        print("\nSome checks failed.")
        sys.exit(1)

if __name__ == "__main__":
    main()
