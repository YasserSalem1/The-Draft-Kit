import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
from pathlib import Path
import sys
import json

# Add project root to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from AI.scripts.dataset import LoLDraftDataset
from AI.scripts.model import LoLTransformer

def calculate_accuracy(logits, targets, k=1, pad_idx=0):
    # logits: [Batch*Seq, Vocab]
    # targets: [Batch*Seq]
    
    mask = targets != pad_idx
    logits = logits[mask]
    targets = targets[mask]
    
    if len(targets) == 0:
        return 0.0
        
    _, pred = logits.topk(k, dim=1, largest=True, sorted=True)
    targets = targets.view(-1, 1).expand_as(pred)
    
    correct = pred.eq(targets).float()
    return correct.sum().item() / len(targets)

def validate(args):
    device = torch.device("cuda" if torch.cuda.is_available() and args.gpu else "cpu")
    print(f"Using device: {device}")
    
    print(f"Loading dataset from {args.data}...")
    ds = LoLDraftDataset(args.data, args.vocab, max_seq_len=150)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=0)
    
    print(f"Loading model from {args.checkpoint}...")
    model = LoLTransformer(
        vocab_size=len(ds.vocab),
        d_model=256,
        nhead=8,
        num_encoder_layers=6,
        num_decoder_layers=6,
        dim_feedforward=1024,
        dropout=0.1,
        pad_idx=ds.pad_idx
    ).to(device)
    
    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
        else:
            model.load_state_dict(checkpoint)
        print("Model loaded successfully.")
    else:
        print(f"Error: Checkpoint {args.checkpoint} not found.")
        return

    criterion = nn.CrossEntropyLoss(ignore_index=ds.pad_idx)
    model.eval()
    
    total_loss = 0
    total_acc1 = 0
    total_acc5 = 0
    steps = 0
    
    print("Running validation...")
    with torch.no_grad():
        for batch in tqdm(loader):
            src = batch['input_tokens'].to(device)
            tgt = batch['target_tokens'].to(device)
            
            tgt_input = tgt[:, :-1]
            tgt_output = tgt[:, 1:]
            
            logits = model(src, tgt_input)
            
            flat_logits = logits.reshape(-1, logits.size(-1))
            flat_tgt = tgt_output.reshape(-1)
            
            loss = criterion(flat_logits, flat_tgt)
            
            total_loss += loss.item()
            total_acc1 += calculate_accuracy(flat_logits, flat_tgt, k=1, pad_idx=ds.pad_idx)
            total_acc5 += calculate_accuracy(flat_logits, flat_tgt, k=5, pad_idx=ds.pad_idx)
            steps += 1
            
    avg_loss = total_loss / steps
    avg_acc1 = total_acc1 / steps
    avg_acc5 = total_acc5 / steps
    
    print("\n" + "="*40)
    print(f"Validation Results for {Path(args.checkpoint).name}")
    print("="*40)
    print(f"Loss:       {avg_loss:.4f}")
    print(f"Top-1 Acc:  {avg_acc1:.4f}")
    print(f"Top-5 Acc:  {avg_acc5:.4f}")
    print("="*40)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", required=True, help="Path to model checkpoint")
    parser.add_argument("--data", default="AI/data/processed/test.parquet", help="Path to test/val data")
    parser.add_argument("--vocab", default="AI/data/metadata/vocab.json", help="Path to vocab")
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--gpu", action="store_true")
    
    args = parser.parse_args()
    validate(args)
