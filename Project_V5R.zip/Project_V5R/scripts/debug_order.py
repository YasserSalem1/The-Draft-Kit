import pandas as pd
import json
from pathlib import Path

def check_order():
    path = Path("AI/data/processed/train.parquet")
    if not path.exists():
        print("File not found")
        return

    df = pd.read_parquet(path)
    print(f"Loaded {len(df)} rows")
    
    # Check first row
    row = df.iloc[0]
    history = json.loads(row['draft_history'])
    remaining = json.loads(row['remaining_sequence'])
    
    print("\nRow 0 Remaining Sequence Steps:")
    steps = [s.get('step') for s in remaining]
    print(steps)
    
    # Check if they look lexicographically sorted
    # Convert to string and see
    str_steps = [str(s) for s in steps]
    sorted_str = sorted(str_steps)
    if str_steps == sorted_str and str_steps != sorted(str_steps, key=int):
        print("\nALERT: Data appears to be sorted Lexicographically!")
    else:
        print("\nData order seems distinct from pure string sort.")

if __name__ == "__main__":
    check_order()
