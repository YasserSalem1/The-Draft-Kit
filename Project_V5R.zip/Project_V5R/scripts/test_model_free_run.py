import sys
import torch
import argparse
import random
import json
from pathlib import Path
from rich.console import Console
from rich.table import Table

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLDraftDataset, LoLTokenizer
from scripts.model import LoLTransformer
from scripts.champion_data import get_champion_role

console = Console()

# Standard Draft Order
DRAFT_ORDER = [
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
]

def free_run_decode(model, history_ids, start_idx, end_idx, device, tokenizer, draft_order, steps_to_generate, max_tokens=300):
    model.eval()
    
    # Context starts with history
    current_ids = [start_idx] + history_ids
    tgt = torch.tensor(current_ids, dtype=torch.long, device=device).unsqueeze(0)
    
    # NOTE: Transformer usually expects src=Encoder, tgt=Decoder.
    # We are using Decoder-only style generation effectively by appending to tgt?
    # Actually, our model is Seq2Seq (Encoder + Decoder).
    # Encoder Input: The CURRENT context.
    # Decoder Input: [START]. Then we continually feed output back to Decoder?
    # NO. 
    # Standard Seq2Seq Inference:
    # 1. Encoder processes Input Sequence (History).
    # 2. Decoder starts with [START].
    # 3. Attributes generated token.
    # 4. Decoder input becomes [START, T1].
    # ...
    # This generates ONE sequence.
    # But this implies the Encoder input is STATIC.
    # In a draft, the "History" grows.
    #
    # How should we model "Free Run"?
    # Option A: Re-run Encoder every step.
    #   Step 11: Enc=[1..10], Dec generates Step 11.
    #   Step 12: Enc=[1..11], Dec generates Step 12.
    # 
    # This is "Autoregressive at the Step Level".
    # This matches training (Predict Remaining given History).
    
    generated_steps_tokens = []
    
    current_history = list(history_ids)
    
    for _ in range(steps_to_generate):
        # Prepare Inputs for THIS Step
        src = torch.tensor([start_idx] + current_history, dtype=torch.long, device=device).unsqueeze(0)
        tgt_inp = torch.full((1, 1), start_idx, dtype=torch.long, device=device)
        
        step_tokens_ids = []
        
        # Generate ONE Step (Role -> Champ -> Class) using constrained logic
        # We assume max tokens per step ~15
        for _ in range(20): 
            with torch.no_grad():
                output = model(src, tgt_inp)
                next_token_logits = output[:, -1, :]
                
                # --- Simple Constrained Masking (Simplified for demo) ---
                # We need to construct the used_champions set from CURRENT history
                used_champions = set()
                # From history
                for idx in current_history:
                     t = tokenizer.id_to_token.get(idx, "")
                     if t not in tokenizer.vocab: continue # Skip UNKs
                     # Rough heuristic for champ
                     if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                         used_champions.add(t)
                
                # From current step generation
                for idx in step_tokens_ids:
                     t = tokenizer.id_to_token.get(idx, "")
                     if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                         used_champions.add(t)
                
                mask = next_token_logits.clone()
                # Basic Masking: Don't repeat champions in this match
                for champ in used_champions:
                    if champ in tokenizer.vocab:
                        mask[0, tokenizer.vocab[champ]] = float('-inf')

                # Don't output structure tokens inappropriately? 
                # Model should learn structure. 
                # We trust model structure for "Free Run", only enforcing unique champs.
                
                next_token = mask.argmax(dim=-1)
                
                if next_token.item() == end_idx:
                    break
                
                token_str = tokenizer.id_to_token.get(next_token.item(), "")
                
                # Check for Step Boundary
                # If we generated a [STEP_X] token, and we already have some tokens (meaning we finished previous step), stop
                if token_str.startswith("STEP_") and len(step_tokens_ids) > 0:
                     # This token belongs to NEXT step.
                     # We stop here.
                     # But do we consume it? No, we want to predict it next time.
                     break
                
                tgt_inp = torch.cat([tgt_inp, next_token.unsqueeze(0)], dim=1)
                step_tokens_ids.append(next_token.item())
        
        # Finished generating one step (or hit limit)
        # Add to history
        current_history.extend(step_tokens_ids)
        generated_steps_tokens.extend(step_tokens_ids)
        
    return current_history # Full history including generated

def decode_ids(ids, tokenizer):
    return [tokenizer.id_to_token.get(i, "") for i in ids]

def parse_step(tokens):
    # Extract Champ, Role from a sequence of tokens
    champ = "NONE"
    role = "UNKNOWN"
    step_num = "?"
    action = "?"
    
    for t in tokens:
        if t.startswith("STEP_"):
            step_num = t.replace("STEP_", "")
        elif "_BAN" in t or "_PICK" in t:
             action = t
        elif t.startswith("ROLE_"):
             role = t.replace("ROLE_", "")
        elif t.startswith("CLASS_") or t.startswith("["):
             continue
        else:
             champ = t
             
    # Fallback role inference
    if role == "UNKNOWN" and champ != "NONE":
        role = get_champion_role(champ)
        
    return step_num, action, champ, role

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/test.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--start_step", type=int, default=10, help="Step to start prediction from (exclusive)")
    parser.add_argument("--match_id", type=str, default=None, help="Optional: Specific match ID to test")
    args = parser.parse_args()

    # Load Tokenizer & Dataset
    try:
        ds = LoLDraftDataset(args.data, args.vocab)
        tokenizer = ds.tokenizer
    except Exception as e:
        console.print(f"[red]Error loading data:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Select Match
    if args.match_id:
        match_id = args.match_id
        if match_id not in ds.data['match_id'].values:
            console.print(f"[red]Match ID {match_id} not found in dataset.[/red]")
            return
    else:
        unique_matches = ds.data['match_id'].unique()
        match_id = random.choice(unique_matches)
    
    match_rows = ds.data[ds.data['match_id'] == match_id].sort_values('sample_id')
    
    start_row = match_rows.iloc[0] 
    full_gt_dicts = json.loads(start_row['remaining_sequence'])
    hist_dicts = json.loads(start_row['draft_history'])
    
    full_match_steps = hist_dicts + full_gt_dicts
    full_match_steps.sort(key=lambda x: int(x.get('step', 0)))
    
    # CUTOFF
    cutoff = args.start_step
    
    gt_history_steps = full_match_steps[:cutoff]
    gt_future_steps = full_match_steps[cutoff:]
    
    # Tokenize History
    history_ids = []
    for s in gt_history_steps:
        history_ids.extend(tokenizer.tokenize([s]))
        
    console.print(f"\n[bold green]Free Run Match {match_id}[/bold green]")
    console.print(f"[dim]Context: First {cutoff} steps provided (Ground Truth).[/dim]")
    console.print(f"[dim]Model predicts remaining {20 - cutoff} steps autonomosly.[/dim]\n")
    
    # RUN PREDICTION
    final_history_ids = free_run_decode(
        model, 
        history_ids=history_ids,
        start_idx=tokenizer.start_idx, 
        end_idx=tokenizer.end_idx, 
        device=device,
        tokenizer=tokenizer,
        draft_order=DRAFT_ORDER,
        steps_to_generate=(20 - cutoff)
    )
    
    # DECODE & DISPLAY
    
    table = Table(title="Free Hallucination vs Ground Truth")
    table.add_column("#", width=4)
    table.add_column("Turn", style="italic")
    table.add_column("Champion", style="bold")
    table.add_column("Status", justify="center")
    
    # We need to parse valid tokens back into steps
    full_tokens = decode_ids(final_history_ids, tokenizer)
    
    # Re-group tokens into steps
    parsed_prediction_steps = []
    current_tokens = []
    
    for t in full_tokens:
        if t.startswith("STEP_") and current_tokens:
             parsed_prediction_steps.append(parse_step(current_tokens))
             current_tokens = [t]
        else:
             current_tokens.append(t)
    if current_tokens:
        parsed_prediction_steps.append(parse_step(current_tokens))
        
    # Render
    for i in range(20):
        step_num = i + 1
        
        # Get GT
        if i < len(full_match_steps):
            gt_obj = full_match_steps[i]
            gt_champ = gt_obj.get('champion', 'UNK')
            gt_role = get_champion_role(gt_champ)
            team = gt_obj.get('team') or gt_obj.get('side') or "UNK"
            action = gt_obj.get('action') or gt_obj.get('type') or "UNK"
            if team != "UNK":
                turn_str = f"{team} {action}"
            else:
                rule = DRAFT_ORDER[i]
                turn_str = f"{rule['side']} {rule['action']}"
        else:
            gt_champ = "---"
            turn_str = "---"
            
        # Get Pred (if matched step)
        if i < len(parsed_prediction_steps):
             p_num, p_action, p_champ, p_role = parsed_prediction_steps[i]
             
             # If step numbers misalign, this visualization breaks.
             # We assume sequential generation.
        else:
             p_champ = "---"
             
        if step_num <= cutoff:
             status = "[dim]HISTORY[/dim]"
             display_champ = f"{gt_champ} ({gt_role})"
        else:
             match = (gt_champ == p_champ)
             icon = "✅" if match else "🔮"
             status = f"[green]MATCH[/green]" if match else "[yellow]DIVERGED[/yellow]"
             
             display_champ = f"[dim]GT: {gt_champ}[/dim]\n[bold cyan]AI: {p_champ} ({p_role})[/bold cyan]"
             
        table.add_row(
            str(step_num),
            turn_str,
            display_champ,
            status
        )
        
    console.print(table)

if __name__ == "__main__":
    main()
