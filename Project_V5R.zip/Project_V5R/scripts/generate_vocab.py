import json
import argparse
import sys
from pathlib import Path
from typing import List, Dict, Set

def generate_vocabulary(input_path: Path, output_dir: Path):
    """
    Generates vocabulary files from match data.
    """
    if not input_path.exists():
        print(f"Error: Input file {input_path} not found.")
        sys.exit(1)

    print(f"Scanning {input_path} for champions...")
    
    unique_champions: Set[str] = set()
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            
        for match in data:
            draft = match.get('draft') or match.get('current_draft', [])
            for step in draft:
                champ = step.get('champion')
                if champ and isinstance(champ, str):
                    unique_champions.add(champ)
                    
    except Exception as e:
        print(f"Error reading data: {e}")
        sys.exit(1)

    # Manually inject champions that might be missing from the dataset (e.g. 0 pick rate or new)
    recent_champions = {
        "Zaahen", "Ambessa", "Aurora", "Smolder", "Hwei", "Briar", "Naafiri", "Milio", "K'Sante",
        "Vel'Koz", "Katarina", "Kayle", "Master Yi", "Nunu & Willump", "Teemo", "Fizz", "Illaoi"
    }
    unique_champions.update(recent_champions)
    
    sorted_champions = sorted(list(unique_champions))
    print(f"Found {len(sorted_champions)} champions (including manual injections).")

    # Scan for Classes
    unique_classes: Set[str] = set()
    try:
        if isinstance(data, list): # Check if data is loaded
             for match in data:
                draft = match.get('draft') or match.get('current_draft', [])
                for step in draft:
                    classes = step.get('champion_class', [])
                    for c in classes:
                        if isinstance(c, str):
                            unique_classes.add(c)
    except Exception as e:
         print(f"Error scanning classes: {e}")
    
    sorted_classes = sorted(list(unique_classes))
    print(f"Found {len(sorted_classes)} champion classes.")

    # Scan for Players and Teams
    unique_players: Set[str] = set()
    unique_teams: Set[str] = set()

    try:
        if isinstance(data, list):
            for match in data:
                draft = match.get('draft') or match.get('current_draft', [])
                for step in draft:
                    # Players (Your Team)
                    p_name = step.get('played_by_player')
                    if p_name and isinstance(p_name, str) and p_name != "Unknown":
                        unique_players.add(p_name)
                    
                    # Players (Opponent)
                    op_name = step.get('played_against_player')
                    if op_name and isinstance(op_name, str) and op_name != "Unknown":
                        unique_players.add(op_name)

                    # Teams (Your Team)
                    t_name = step.get('played_by_team') or step.get('banned_by_team')
                    if t_name and isinstance(t_name, str) and t_name != "Unknown":
                        unique_teams.add(t_name)
                    
                    # Teams (Opponent)
                    oa_name = step.get('played_against_team') or step.get('banned_against_team')
                    if oa_name and isinstance(oa_name, str) and oa_name != "Unknown":
                        unique_teams.add(oa_name)
    except Exception as e:
        print(f"Error scanning players/teams: {e}")

    print(f"Found {len(unique_players)} unique players.")
    print(f"Found {len(unique_teams)} unique teams.")

    # Define Special Tokens
    special_tokens = ["[PAD]", "[START]", "[END]", "[SEP]"]

    
    # Define Action Tokens
    action_tokens = ["BLUE_BAN", "RED_BAN", "BLUE_PICK", "RED_PICK"]
    
    # Define Role Tokens
    role_tokens = ["ROLE_TOP", "ROLE_JUNGLE", "ROLE_MID", "ROLE_BOT", "ROLE_SUPPORT", "ROLE_UNKNOWN"]

    # Define Class Tokens
    class_tokens = [f"CLASS_{c}" for c in sorted_classes]
    
    # Define Step Tokens (STEP_1 to STEP_20)
    step_tokens = [f"STEP_{i}" for i in range(1, 21)]

    # Define Player and Team Tokens (Normalized)
    # We replace spaces with underscores to keep tokens clean
    player_tokens = [f"PLAYER_{p.replace(' ', '_')}" for p in sorted(list(unique_players))]
    team_tokens = [f"TEAM_{t.replace(' ', '_')}" for t in sorted(list(unique_teams))]

    # Combine all tokens in deterministic order
    # Order: Special -> Actions -> Roles -> Classes -> Steps -> TEAMS -> PLAYERS -> Champions
    # Adding Teams/Players before Champs 
    all_tokens = special_tokens + action_tokens + role_tokens + class_tokens + step_tokens + team_tokens + player_tokens + sorted_champions
    
    vocab_map = {token: idx for idx, token in enumerate(all_tokens)}
    
    # Champion only maps (useful for just champion ID lookup independent of full vocab if needed,
    # but the user requested 'data/metadata/champion_to_id.json' which specifically usually implies just champs
    # mapped to their IDs *within the vocab* or separate IDs? 
    # The prompt asks for a "Vocabulary" with these tokens. And then specific champion maps.
    # Usually champion_to_id in this context means mapping the champion string to its Token ID.
    
    champion_to_id = {champ: vocab_map[champ] for champ in sorted_champions}
    id_to_champion = {vocab_map[champ]: champ for champ in sorted_champions}

    # Ensure output directory exists
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Save vocab.json (Full token -> ID map)
    vocab_path = output_dir / "vocab.json"
    with open(vocab_path, 'w', encoding='utf-8') as f:
        json.dump(vocab_map, f, indent=2)
        
    # Save champion_to_id.json
    c2i_path = output_dir / "champion_to_id.json"
    with open(c2i_path, 'w', encoding='utf-8') as f:
        json.dump(champion_to_id, f, indent=2)

    # Save id_to_champion.json
    i2c_path = output_dir / "id_to_champion.json"
    with open(i2c_path, 'w', encoding='utf-8') as f:
        json.dump(id_to_champion, f, indent=2)

    print("\nVocabulary Generation Complete!")
    print(f"Total Vocabulary Size: {len(all_tokens)}")
    print(f"  - Special Tokens: {len(special_tokens)}")
    print(f"  - Action Tokens:  {len(action_tokens)}")
    print(f"  - Role Tokens:    {len(role_tokens)}")
    print(f"  - Class Tokens:   {len(class_tokens)}")
    print(f"  - Step Tokens:    {len(step_tokens)}")
    print(f"  - Team Tokens:    {len(team_tokens)}")
    print(f"  - Player Tokens:  {len(player_tokens)}")
    print(f"  - Champions:      {len(sorted_champions)}")
    print(f"\nSaved to {output_dir}/")
    print(f"  - vocab.json")
    print(f"  - champion_to_id.json")
    print(f"  - id_to_champion.json")

def main():
    parser = argparse.ArgumentParser(description="Generate vocabulary for LoL Draft Transformer.")
    parser.add_argument("--input", default="data/raw/all_games.json", help="Path to input raw data JSON")
    parser.add_argument("--output_dir", default="data/metadata", help="Directory to save metadata")
    
    args = parser.parse_args()
    
    generate_vocabulary(Path(args.input), Path(args.output_dir))

if __name__ == "__main__":
    main()
