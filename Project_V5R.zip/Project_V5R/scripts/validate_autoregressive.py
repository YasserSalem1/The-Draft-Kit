import sys
import torch
import argparse
import random
import json
import numpy as np
from pathlib import Path
from rich.console import Console
from rich.table import Table
from tqdm import tqdm

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLDraftDataset, LoLTokenizer
from scripts.model import LoLTransformer
from scripts.champion_data import get_champion_role

console = Console()

# Standard Draft Order
DRAFT_ORDER = [
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
]

def free_run_decode(model, start_idx, end_idx, device, tokenizer, draft_order, steps_to_generate=20):
    model.eval()
    
    # Context starts empty (just START)
    current_history = []
    
    generated_steps_tokens = []
    
    for _ in range(steps_to_generate):
        # Prepare Inputs for THIS Step
        src = torch.tensor([start_idx] + current_history, dtype=torch.long, device=device).unsqueeze(0)
        tgt_inp = torch.full((1, 1), start_idx, dtype=torch.long, device=device)
        
        step_tokens_ids = []
        
        # Generate ONE Step (Role -> Champ -> Class) using constrained logic
        for _ in range(20): 
            with torch.no_grad():
                output = model(src, tgt_inp)
                next_token_logits = output[:, -1, :]
                
                # --- Quick Constrained Masking ---
                used_champions = set()
                # From history
                for idx in current_history:
                     t = tokenizer.id_to_token.get(idx, "")
                     if t not in tokenizer.vocab: continue
                     if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                         used_champions.add(t)
                
                # From current step generation
                for idx in step_tokens_ids:
                     t = tokenizer.id_to_token.get(idx, "")
                     if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                         used_champions.add(t)
                
                mask = next_token_logits.clone()
                for champ in used_champions:
                    if champ in tokenizer.vocab:
                        mask[0, tokenizer.vocab[champ]] = float('-inf')

                next_token = mask.argmax(dim=-1)
                
                if next_token.item() == end_idx:
                    break
                
                token_str = tokenizer.id_to_token.get(next_token.item(), "")
                
                if token_str.startswith("STEP_") and len(step_tokens_ids) > 0:
                     break
                
                tgt_inp = torch.cat([tgt_inp, next_token.unsqueeze(0)], dim=1)
                step_tokens_ids.append(next_token.item())
        
        current_history.extend(step_tokens_ids)
        generated_steps_tokens.extend(step_tokens_ids)
        
    return current_history

def decode_ids(ids, tokenizer):
    return [tokenizer.id_to_token.get(i, "") for i in ids]

def parse_step_tokens(tokens):
    # Split full list of tokens into steps list
    steps = []
    current_step_toks = []
    
    for t in tokens:
        if t.startswith("STEP_"):
            if current_step_toks:
                steps.append(current_step_toks)
            current_step_toks = [t]
        else:
            current_step_toks.append(t)
    if current_step_toks:
         steps.append(current_step_toks)
    return steps

def extract_champion(step_tokens):
    for t in step_tokens:
        if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
            return t
    return "NONE"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/test.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--limit", type=int, default=50, help="Number of matches to validate")
    args = parser.parse_args()

    # Load Tokenizer & Dataset
    try:
        ds = LoLDraftDataset(args.data, args.vocab)
        tokenizer = ds.tokenizer
    except Exception as e:
        console.print(f"[red]Error loading data:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Select Matches
    unique_matches = ds.data['match_id'].unique()
    if args.limit > 0 and args.limit < len(unique_matches):
        selected_matches = np.random.choice(unique_matches, args.limit, replace=False)
    else:
        selected_matches = unique_matches
    
    console.print(f"\n[bold green]Running Autoregressive Validation on {len(selected_matches)} Matches...[/bold green]")

    # Metrics
    # step_accuracies[i] = [1, 0, 1, ...] for step i+1
    step_accuracy_hits = {i: 0 for i in range(1, 21)}
    step_accuracy_total = {i: 0 for i in range(1, 21)}
    
    match_accuracies = []

    for match_id in tqdm(selected_matches):
        # Get Ground Truth
        match_rows = ds.data[ds.data['match_id'] == match_id].sort_values('sample_id')
        if len(match_rows) == 0: continue
        
        start_row = match_rows.iloc[0]
        full_gt_dicts = json.loads(start_row['remaining_sequence'])
        hist_dicts = json.loads(start_row['draft_history'])
        full_match_steps = hist_dicts + full_gt_dicts
        full_match_steps.sort(key=lambda x: int(x.get('step', 0)))
        
        # We need first 20 steps
        gt_champions = []
        for i in range(20):
            if i < len(full_match_steps):
                gt_champions.append(full_match_steps[i].get('champion', 'UNKNOWN'))
            else:
                gt_champions.append("UNKNOWN")
        
        # Run Model (From Scratch)
        final_history_ids = free_run_decode(
            model, 
            start_idx=tokenizer.start_idx, 
            end_idx=tokenizer.end_idx, 
            device=device,
            tokenizer=tokenizer,
            draft_order=DRAFT_ORDER,
            steps_to_generate=20
        )
        
        full_tokens = decode_ids(final_history_ids, tokenizer)
        parsed_steps = parse_step_tokens(full_tokens)
        
        match_hits = 0
        
        for i in range(20):
            step_num = i + 1
            if i < len(parsed_steps):
                pred_champ = extract_champion(parsed_steps[i])
            else:
                pred_champ = "NONE"
            
            gt_champ = gt_champions[i]
            
            is_correct = (pred_champ == gt_champ)
            if is_correct:
                step_accuracy_hits[step_num] += 1
                match_hits += 1
            step_accuracy_total[step_num] += 1
            
        match_accuracies.append(match_hits / 20.0)

    # Report
    table = Table(title="Autoregressive Accuracy per Step (From Scratch)")
    table.add_column("Step", justify="right")
    table.add_column("Hits/Total", justify="right")
    table.add_column("Accuracy", style="bold green")
    
    for i in range(1, 21):
        if step_accuracy_total[i] > 0:
            acc = step_accuracy_hits[i] / step_accuracy_total[i]
            table.add_row(f"Step {i}", f"{step_accuracy_hits[i]}/{step_accuracy_total[i]}", f"{acc*100:.1f}%")
    
    console.print(table)
    
    avg_match_acc = np.mean(match_accuracies) * 100
    console.print(f"\n[bold]Average Match Accuracy (Free Run): {avg_match_acc:.1f}%[/bold]")

if __name__ == "__main__":
    main()
