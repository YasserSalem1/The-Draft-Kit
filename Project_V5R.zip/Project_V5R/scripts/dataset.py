import json
import torch
import pandas as pd
import numpy as np
from pathlib import Path
from torch.utils.data import Dataset
from typing import Dict, List, Tuple, Any, Optional

class LoLTokenizer:
    def __init__(self, vocab_path: str):
        self.vocab_path = Path(vocab_path)
        if not self.vocab_path.exists():
            raise FileNotFoundError(f"Vocab file not found at {self.vocab_path}")
            
        with open(self.vocab_path, 'r', encoding='utf-8') as f:
            self.vocab = json.load(f)
            
        self.id_to_token = {v: k for k, v in self.vocab.items()}
        
        # Verify Special Tokens
        self.pad_idx = self.vocab.get("[PAD]")
        self.start_idx = self.vocab.get("[START]")
        self.end_idx = self.vocab.get("[END]")
        self.sep_idx = self.vocab.get("[SEP]")
        
        if None in [self.pad_idx, self.start_idx, self.end_idx, self.sep_idx]:
             raise ValueError("Vocabulary missing required special tokens")

    def tokenize(self, step_list: List[Dict[str, Any]]) -> List[int]:
        """
        Converts a list of draft steps (dicts) into a list of token IDs.
        """
        tokens = []
        for step_data in step_list:
            # 1. Step Token
            step_num = step_data.get("step")
            step_token = f"STEP_{step_num}"
            
            # 2. Action Token
            # Construct ACTION (e.g. BLUE_BAN, RED_PICK)
            team = step_data.get("team")
            # If explicit team/action missing, try to infer (legacy/raw data support)
            # But normally we expect processed input or we infer.
            # INFERENCE LOGIC (Recovered from previous turn):
            if team is None or "action" not in step_data:
                # Deduce based on step number for standard draft
                s = int(step_num)
                if s in [1, 3, 5, 14, 16]: side, type_ = "BLUE", "BAN"
                elif s in [2, 4, 6, 13, 15]: side, type_ = "RED", "BAN"
                elif s in [7, 10, 11, 18, 19]: side, type_ = "BLUE", "PICK"
                elif s in [8, 9, 12, 17, 20]: side, type_ = "RED", "PICK"
                else: side, type_ = "BLUE", "UNKNOWN" 
                
                # Override if we deduced it
                if "team" not in step_data: team = side
                if "action" not in step_data: action = type_
                
                action_token = f"{side}_{type_}"
            else:
                action = step_data.get("action")
                action_token = f"{team}_{action}"

            # 3. Role Token
            role = step_data.get("role", step_data.get("primary_role", "UNKNOWN"))
            if role is None: role = "UNKNOWN"
            role_token = f"ROLE_{role}"

            # 4. Champion Token
            champion = step_data.get("champion")
            
            # 5. Class Tokens
            classes = step_data.get("champion_class", [])
            class_tokens = [f"CLASS_{c}" for c in classes]

            # 6. Player Token
            player_name = step_data.get("played_by_player")
            player_token = None
            if player_name and isinstance(player_name, str) and player_name != "Unknown":
                norm_name = player_name.replace(" ", "_")
                player_token = f"PLAYER_{norm_name}"

            # 7. Team Tokens
            # Your Team
            team_org = step_data.get("played_by_team") or step_data.get("banned_by_team")
            team_token = None
            if team_org and isinstance(team_org, str) and team_org != "Unknown":
                norm_team = team_org.replace(" ", "_")
                team_token = f"TEAM_{norm_team}"
            
            # Opponent Team
            opp_team_org = step_data.get("played_against_team") or step_data.get("banned_against_team")
            opp_team_token = None
            if opp_team_org and isinstance(opp_team_org, str) and opp_team_org != "Unknown":
                norm_opp_team = opp_team_org.replace(" ", "_")
                opp_team_token = f"OPP_TEAM_{norm_opp_team}"

            # 8. Opponent Player Token
            opp_player_name = step_data.get("played_against_player")
            opp_player_token = None
            if opp_player_name and isinstance(opp_player_name, str) and opp_player_name != "Unknown":
                norm_opp_name = opp_player_name.replace(" ", "_")
                opp_player_token = f"OPP_PLAYER_{norm_opp_name}"

            # Lookup and Append
            if step_token not in self.vocab:
                 raise ValueError(f"Unknown step token: {step_token}")
            
            if action_token not in self.vocab:
                 raise ValueError(f"Unknown action token: {action_token}")
                 
            if role_token not in self.vocab:
                 role_token = self.vocab.get("ROLE_UNKNOWN", role_token)

            if champion not in self.vocab:
                 raise ValueError(f"Unknown champion token: {champion}")
                 
            # Build list: [STEP] [ACTION] [TEAM] [OPP_TEAM] [PLAYER] [OPP_PLAYER] [ROLE] [CHAMP]
            
            step_tokens_ids = [self.vocab[step_token], self.vocab[action_token]]
            
            if team_token and team_token in self.vocab: step_tokens_ids.append(self.vocab[team_token])
            # Note: We reuse the same vocab namespace ("TEAM_X") for both playing and opposing teams?
            # Or should we have specific "OPP_TEAM_X" tokens?
            # The prompt asked to use the data. To differentiate "I am T1" vs "I am playing against T1",
            # we simply use the POSITION in the sequence, OR explicit tokens.
            # Explicit tokens are safer for transformers to distinguish roles immediately.
            # However, generate_vocab only generated "TEAM_X".
            # If we want "OPP_TEAM_X", we need to change generate_vocab to generate "OPP_TEAM_" prefix too?
            # actually, using the SAME token (TEAM_T1) but in a different position is standard embedding practice,
            # BUT our sequence is flattened.
            # So "TEAM_T1" followed by "TEAM_G2" might be ambiguous?
            # Actually, `generate_vocab` just created "TEAM_X".
            # Let's stick to "TEAM_X" for both. The model learns: The first team token in the step is the ACTOR. 
            # The second team token is the OPPONENT (if present).
            # This relies on positional encoding.
            
            if opp_team_token:
                # We need to check if we generated OPP_TEAM_ in vocab? 
                # I did NOT add "OPP_" prefix in generate_vocab. I only added "TEAM_".
                # So I should use "TEAM_{opp_name}" token.
                # Just reuse the team token.
                
                # RE-READ generate_vocab:
                # team_tokens = [f"TEAM_{t.replace(' ', '_')}" for t in sorted(list(unique_teams))]
                # It does NOT verify source.
                
                norm_opp_team_generic = f"TEAM_{opp_team_org.replace(' ', '_')}"
                if norm_opp_team_generic in self.vocab:
                    step_tokens_ids.append(self.vocab[norm_opp_team_generic])
            
            if player_token and player_token in self.vocab: step_tokens_ids.append(self.vocab[player_token])
            
            if opp_player_name: # Similarly, use PLAYER_X token for opponent
                 norm_opp_player_generic = f"PLAYER_{opp_player_name.replace(' ', '_')}"
                 if norm_opp_player_generic in self.vocab:
                     step_tokens_ids.append(self.vocab[norm_opp_player_generic])

            step_tokens_ids.append(self.vocab[role_token])
            step_tokens_ids.append(self.vocab[champion])
            
            for ct in class_tokens:
                if ct in self.vocab:
                    step_tokens_ids.append(self.vocab[ct])
            
            tokens.extend(step_tokens_ids)
            
        return tokens

class LoLDraftDataset(Dataset):
    """
    PyTorch Dataset for League of Legends Drafts.
    """
    def __init__(
        self, 
        parquet_path: str, 
        vocab_path: str, 
        max_seq_len: int = 150
    ):
        self.parquet_path = Path(parquet_path)
        self.tokenizer = LoLTokenizer(vocab_path)
        self.max_seq_len = max_seq_len
        
        # Expose vocab/pad attributes for convenience/backward compat
        self.vocab = self.tokenizer.vocab
        self.pad_idx = self.tokenizer.pad_idx
        self.start_idx = self.tokenizer.start_idx
        self.end_idx = self.tokenizer.end_idx
        self.sep_idx = self.tokenizer.sep_idx
        
        # Load Data
        if not self.parquet_path.exists():
            raise FileNotFoundError(f"Data file not found at {self.parquet_path}")
            
        self.data = pd.read_parquet(self.parquet_path)
        
    def __len__(self):
        return len(self.data)
        
    def __getitem__(self, idx) -> Dict[str, torch.Tensor]:
        row = self.data.iloc[idx]
        
        # Parse JSON
        draft_history = json.loads(row['draft_history'])
        remaining_sequence = json.loads(row['remaining_sequence'])
        
        # Tokenize using tokenizer
        history_ids = self.tokenizer.tokenize(draft_history)
        remaining_ids = self.tokenizer.tokenize(remaining_sequence)
        
        # Construct Input (Encoder)
        input_ids = [self.start_idx] + history_ids
        
        # Construct Target (Decoder)
        target_ids = [self.start_idx] + remaining_ids + [self.end_idx]
        
        # Truncate
        if len(input_ids) > self.max_seq_len:
            input_ids = input_ids[-self.max_seq_len:]
            
        if len(target_ids) > self.max_seq_len:
            target_ids = target_ids[:self.max_seq_len]
            
        # PADDING
        input_len = len(input_ids)
        target_len = len(target_ids)
        
        pad_input_len = self.max_seq_len - input_len
        pad_target_len = self.max_seq_len - target_len
        
        # Create Tensors
        input_tensor = torch.tensor(input_ids + [self.pad_idx] * pad_input_len, dtype=torch.long)
        target_tensor = torch.tensor(target_ids + [self.pad_idx] * pad_target_len, dtype=torch.long)
        
        # Create Masks (1 for valid, 0 for pad)
        input_mask = torch.tensor([1] * input_len + [0] * pad_input_len, dtype=torch.long)
        target_mask = torch.tensor([1] * target_len + [0] * pad_target_len, dtype=torch.long)
        
        return {
            "input_tokens": input_tensor,
            "target_tokens": target_tensor,
            "input_mask": input_mask,
            "target_mask": target_mask,
            "match_id": row['match_id'],
            "sample_id": row['sample_id']
        }

if __name__ == "__main__":
    # Self-test block
    print("Testing LoLDraftDataset...")
    data_path = Path("AI/data/processed/train.parquet")
    vocab_path = Path("AI/data/metadata/vocab.json")
    
    if not data_path.exists() or not vocab_path.exists():
        print("Data or Vocab not found, skipping test.")
    else:
        ds = LoLDraftDataset(data_path, vocab_path)
        print(f"Dataset size: {len(ds)}")
        
        item = ds[0]
        print("\nSample 0:")
        print(f"Input Shape: {item['input_tokens'].shape}")
        
        ids = item['input_tokens'].tolist()
        # use tokenizer to inverse? ID_TO_TOKEN is in tokenizer
        tokens = [ds.tokenizer.id_to_token[i] for i in ids if i != ds.pad_idx]
        print(f"Decoded Input: {tokens}")
