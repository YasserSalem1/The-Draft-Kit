import sys
import torch
import argparse
import random
import json
from pathlib import Path
from rich.console import Console
from rich.table import Table

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLDraftDataset, LoLTokenizer
from scripts.model import LoLTransformer
from scripts.champion_data import get_champion_role

console = Console()

# Standard Draft Order
DRAFT_ORDER = [
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
]

def constrained_greedy_decode(model, history_ids, start_idx, end_idx, device, tokenizer, draft_order, max_len=150):
    model.eval()
    
    # Encoder Input: [START] + History
    src_ids = [start_idx] + history_ids
    src = torch.tensor(src_ids, dtype=torch.long, device=device).unsqueeze(0)
    
    # Decoder Input: [START]
    tgt = torch.full((1, 1), start_idx, dtype=torch.long, device=device)
    
    structure_tokens = set()
    for t, idx in tokenizer.vocab.items():
        if t.startswith("STEP_") or t.endswith("_BAN") or t.endswith("_PICK") or t.startswith("["):
            structure_tokens.add(idx)
    
    generated_ids = []
    
    for _ in range(max_len):
        with torch.no_grad():
            output = model(src, tgt)
            next_token_logits = output[:, -1, :]
            
            # --- CONSTRAINED MASKING LOGIC ---
            current_generated = tgt[0].tolist()
            
            used_champions = set()
            # Parse history for used champions
            for h_idx in history_ids:
                t = tokenizer.id_to_token.get(h_idx, "")
                if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                     used_champions.add(t)
            
            # Parse currently generated tokens
            for g_idx in current_generated:
                t = tokenizer.id_to_token.get(g_idx, "")
                if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
                     used_champions.add(t)
            
            current_phase = "START" 
            current_step_num = 0
            
            # Scan generated to find current state
            for idx in current_generated:
                if idx in [start_idx, tokenizer.pad_idx, tokenizer.sep_idx, tokenizer.end_idx]:
                    continue
                token = tokenizer.id_to_token.get(idx, "")
                
                if token.startswith("STEP_"):
                    current_step_num = int(token.replace("STEP_", ""))
                    current_phase = "STEP"
                elif "_BAN" in token or "_PICK" in token:
                    current_phase = "ACTION"
                elif token.startswith("ROLE_"):
                    current_phase = "ROLE"
                elif token.startswith("CLASS_"):
                    current_phase = "CLASS"
                else: 
                     current_phase = "CHAMPION"

            # Determine Valid Next Tokens
            valid_tokens = []
            
            if current_phase == "START":
                # Must predict NEXT Step relative to History
                last_hist_step = 0
                for h_idx in reversed(history_ids):
                     t = tokenizer.id_to_token.get(h_idx, "")
                     if t.startswith("STEP_"):
                         last_hist_step = int(t.replace("STEP_", ""))
                         break
                
                next_step = last_hist_step + 1
                if next_step <= len(draft_order):
                    valid_tokens = [f"STEP_{next_step}"]
            
            elif current_phase == "STEP":
                 if 0 <= current_step_num - 1 < len(draft_order):
                    rule = draft_order[current_step_num - 1]
                    action_token = f"{rule['side']}_{rule['action']}"
                    valid_tokens = [action_token]

            # Create Mask
            mask = next_token_logits.clone()
            
            if current_phase == "ACTION":
                 mask.fill_(float('-inf'))
                 for t, t_idx in tokenizer.vocab.items():
                    if t.startswith("ROLE_"):
                         mask[0, t_idx] = next_token_logits[0, t_idx]
            
            elif current_phase == "ROLE":
                 mask = next_token_logits.clone()
                 for s_idx in structure_tokens: mask[0, s_idx] = float('-inf')
                 for t, t_idx in tokenizer.vocab.items():
                    if t.startswith("ROLE_") or t.startswith("CLASS_"):
                         mask[0, t_idx] = float('-inf')
                 for champ in used_champions:
                    if champ in tokenizer.vocab:
                        mask[0, tokenizer.vocab[champ]] = float('-inf')

            elif current_phase == "START" or current_phase == "STEP":
                 mask.fill_(float('-inf'))
                 for vt in valid_tokens:
                     if vt in tokenizer.vocab:
                         mask[0, tokenizer.vocab[vt]] = next_token_logits[0, tokenizer.vocab[vt]]

            next_token = mask.argmax(dim=-1)
            
            if next_token.item() == end_idx:
                break
            
            token_str = tokenizer.id_to_token.get(next_token.item(), "")
            if token_str.startswith("STEP_") and len(current_generated) > 1:
                 break
            
            tgt = torch.cat([tgt, next_token.unsqueeze(0)], dim=1)
            generated_ids.append(next_token.item())
            
    return generated_ids

def decode_ids(ids, tokenizer):
    return [tokenizer.id_to_token.get(i, "") for i in ids]

def find_champion_in_tokens(tokens):
    for t in tokens:
        if not (t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN"):
            return t
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/train.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--device", type=str, default="cpu")
    parser.add_argument("--match_id", type=str, default=None)
    args = parser.parse_args()

    # Load Tokenizer & Dataset
    try:
        ds = LoLDraftDataset(args.data, args.vocab)
        tokenizer = ds.tokenizer
    except Exception as e:
        console.print(f"[red]Error loading data:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Select Match
    if args.match_id:
        match_id = args.match_id
        match_rows = ds.data[ds.data['match_id'] == match_id].sort_values('sample_id')
        if len(match_rows) == 0:
            console.print(f"[red]Match ID {match_id} not found.[/red]")
            return
    else:
        unique_matches = ds.data['match_id'].unique()
        match_id = random.choice(unique_matches)
        match_rows = ds.data[ds.data['match_id'] == match_id].sort_values('sample_id')
    
    # Reconstruct Full Ground Truth Sequence
    start_row = match_rows.iloc[0] 
    
    # Check if sample 0 has empty history or if it's mid-draft (shouldn't be if sorted)
    # We assume sample_id 0 is start.
    full_gt_dicts = json.loads(start_row['remaining_sequence'])
    hist_dicts = json.loads(start_row['draft_history']) # Should be empty or minimal
    
    full_match_steps = hist_dicts + full_gt_dicts
    full_match_steps.sort(key=lambda x: int(x.get('step', 0))) # Ensure strict order
    
    console.print(f"\n[bold green]Comparing vs Ground Truth for Match {match_id}[/bold green]")
    
    table = Table(title=f"Match {match_id} - Model Prediction vs Ground Truth")
    table.add_column("#", style="dim", width=4)
    table.add_column("Turn", style="italic")
    table.add_column("Ground Truth", style="bold green")
    table.add_column("Predicted", style="bold yellow")
    table.add_column("Match?", justify="center")

    accumulated_history_ids = []
    # If hist_dicts was not empty, we need to tokenize it and add to accumulated_history_ids?
    # Actually, if we want to predict STEP 1, history must be empty.
    # If sample 0 already has history (e.g. data augmentation cut it), we can't easily predict step 1.
    # But usually sample_id starts at 0 with empty history.
    
    correct_count = 0
    total_steps = 0

    for step_obj in full_match_steps:
        step_num = int(step_obj['step'])
        if step_num > 20: break
        
        gt_champ = step_obj.get('champion', 'UNKNOWN')
        gt_role = get_champion_role(gt_champ)
        
        # Inference Team/Action Logic
        p_team = step_obj.get("team") or step_obj.get("side") or "UNK"
        p_action = step_obj.get("action") or step_obj.get("type") or "UNK"
        
        if p_team != "UNK":
             turn_str = f"{p_team} {p_action}"
        else:
             turn_str = f"Step {step_num}"

        # PREDICT
        pred_ids = constrained_greedy_decode(
            model, 
            history_ids=accumulated_history_ids,
            start_idx=tokenizer.start_idx, 
            end_idx=tokenizer.end_idx, 
            device=device,
            tokenizer=tokenizer,
            draft_order=DRAFT_ORDER
        )
        
        pred_tokens = decode_ids(pred_ids, tokenizer)
        pred_champ = find_champion_in_tokens(pred_tokens)
        
        if pred_champ is None: pred_champ = "NONE"
        pred_role = get_champion_role(pred_champ)
        
        is_match = (pred_champ == gt_champ)
        match_mark = "✅" if is_match else "❌"
        if is_match: correct_count += 1
        total_steps += 1
        
        table.add_row(
            str(step_num),
            turn_str,
            f"{gt_champ} ({gt_role})",
            f"{pred_champ} ({pred_role})",
            match_mark
        )
        
        # UPDATE HISTORY: Use GT Token
        step_tokens = tokenizer.tokenize([step_obj])
        accumulated_history_ids.extend(step_tokens)

    console.print(table)
    console.print(f"\n[bold]Session Accuracy:[/bold] {correct_count}/{total_steps} ({correct_count/total_steps*100:.1f}%)")

if __name__ == "__main__":
    main()
