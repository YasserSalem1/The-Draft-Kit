import torch
import argparse
import json
import sys
from pathlib import Path
from rich.console import Console
from rich.table import Table

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLTokenizer
from scripts.model import LoLTransformer

console = Console()

def get_recommendations(model, tokenizer, history_ids, top_k=5, device='cpu'):
    model.eval()
    
    # 1. Prepare Input
    input_ids = [tokenizer.start_idx] + history_ids
    input_tensor = torch.tensor(input_ids, dtype=torch.long, device=device).unsqueeze(0)
    
    # 2. Get Logits for the NEXT token
    # We want to predict the *Champion*.
    # Usually the sequence is [START] [STEP] [ACTION] [TEAM] [ROLE] [CHAMPION]
    # To get Champion recommendations, we ideally want to provide the *Context* (Step/Role) and ask for the Champ.
    # However, if we just feed history, the model might first predict the [STEP] token.
    # We want to see what Champion it thinks is best *assuming* we are at the drafting phase.
    
    # Strategy:
    # Run the model. Get predictions for the next token.
    # If the next token is a CHAMPION, great. 
    # If it's a structural token (STEP/ROLE), we might need to *force* feed those to get to the Champion part.
    # But usually, a "Recommendation" implies "I want to pick for Next Step".
    # Let's assume we want to predict the CHAMPION for the NEXT step.
    
    # Simplified approach for this script:
    # Just show the Top-K tokens overall, filtering only for Champions.
    # This answers: "What Champion is the model thinking about right now?"
    
    with torch.no_grad():
        # Feed encoder-only (or standard forward)
        # Using a dummy target [START] to kickstart decoder
        tgt = torch.tensor([[tokenizer.start_idx]], dtype=torch.long, device=device)
        
        output = model(input_tensor, tgt)
        logits = output[:, -1, :]
        
        # Mask everything except Champions
        mask = torch.full_like(logits, float('-inf'))
        
        for token, idx in tokenizer.vocab.items():
            # Basic check: It's a champion if it's NOT a special token
            # Our champions are just names.
            if not token.startswith("STEP_") and \
               not token.startswith("ROLE_") and \
               not token.startswith("CLASS_") and \
               not token.startswith("TEAM_") and \
               not token.startswith("PLAYER_") and \
               not token.startswith("OPP_") and \
               not token.startswith("[") and \
               "_" not in token: # Most special tokens have underscores (BLUE_BAN etc), except Champs with spaces
                
                # Double check champions with underscores (e.g. Miss_Fortune if we normalized? No, existing vocab has spaces)
                # Let's use exclusion list of known prefixes/suffixes
                if token not in ["BLUE_BAN", "RED_BAN", "BLUE_PICK", "RED_PICK", "UNKNOWN"]:
                     mask[0, idx] = logits[0, idx]

        # Explicitly allow champs with spaces that might have failed the check
        # Better: Iterate champions list if we had it.
        # Heuristic: If it has no prefix "XYZ_", it's likely a champ.
        
        probs = torch.softmax(mask, dim=-1)
        top_probs, top_indices = torch.topk(probs, top_k)
        
        recs = []
        for prob, idx in zip(top_probs[0], top_indices[0]):
            token = tokenizer.id_to_token[idx.item()]
            recs.append((token, prob.item()))
            
        return recs

def main():
    parser = argparse.ArgumentParser(description="Get Top-5 Recommendations for the next pick.")
    parser.add_argument("--checkpoint", type=str, required=True, help="Path to model checkpoint")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--history", type=str, help="JSON string of draft history list", default="[]")
    parser.add_argument("--device", type=str, default="cpu")
    
    args = parser.parse_args()
    
    # Load Tokenizer & Model
    try:
        tokenizer = LoLTokenizer(args.vocab)
        device = torch.device(args.device)
        model = LoLTransformer(vocab_size=len(tokenizer.vocab)).to(device)
        
        state_dict = torch.load(args.checkpoint, map_location=device)
        if 'model_state_dict' in state_dict: state_dict = state_dict['model_state_dict']
        model.load_state_dict(state_dict)
    except Exception as e:
        console.print(f"[red]Error loading model: {e}[/red]")
        return
        
    # Parse History
    try:
        history_list = json.loads(args.history)
        history_ids = tokenizer.tokenize(history_list)
    except:
        console.print("[red]Invalid history format.[/red] Provide valid JSON list.")
        return

    console.print(f"[bold]Analyzing Context with {len(history_list)} steps...[/bold]")
    
    recs = get_recommendations(model, tokenizer, history_ids, top_k=5, device=device)
    
    table = Table(title="🤖 AI Recommendations")
    table.add_column("Rank", style="cyan", justify="center")
    table.add_column("Champion", style="bold green")
    table.add_column("Confidence", style="magenta")
    
    for i, (champ, prob) in enumerate(recs, 1):
        table.add_row(str(i), champ, f"{prob*100:.1f}%")
        
    console.print(table)
    console.print("\n[dim]Run this script iteratively with updated history to simulate a live draft.[/dim]")

if __name__ == "__main__":
    main()
