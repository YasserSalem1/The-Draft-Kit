import sys
import torch
import json
import argparse
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLTokenizer
from scripts.model import LoLTransformer

console = Console()

# Standard Draft Order
DRAFT_ORDER = [
    # Phase 1 Bans
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_1', 'side': 'RED', 'action': 'BAN'},
    # Phase 1 Picks
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_1', 'side': 'RED', 'action': 'PICK'},
    # Phase 2 Bans
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'RED', 'action': 'BAN'},
    {'phase': 'BAN_2', 'side': 'BLUE', 'action': 'BAN'},
    # Phase 2 Picks
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'BLUE', 'action': 'PICK'},
    {'phase': 'PICK_2', 'side': 'RED', 'action': 'PICK'},
]

def constrained_greedy_decode(model, src, max_len, start_idx, end_idx, device, tokenizer, draft_order):
    model.eval()
    tgt = torch.full((1, 1), start_idx, dtype=torch.long, device=device)
    
    # Pre-identify structure tokens for faster filtering
    structure_tokens = set()
    for t, idx in tokenizer.vocab.items():
        if t.startswith("STEP_") or t.endswith("_BAN") or t.endswith("_PICK") or t.startswith("["):
            structure_tokens.add(idx)

    # Initial Context from Source
    # src is [1, Seq]
    history_ids = src[0].tolist()
    
    for _ in range(max_len):
        with torch.no_grad():
            output = model(src, tgt)
            next_token_logits = output[:, -1, :]
            
            # --- CONSTRAINED DECODING ---
            
            # 1. Parse Current State
            # Combine history + generated
            current_generated = tgt[0].tolist()
            # Skip start token of generated if history has one, but here history is full context
            # and tgt is response.
            # Actually, standard transformer: src is encoded, tgt is decoded.
            # But specific to this logic: the "Context" is the full sequence.
            
            # Sequence reconstruction
            # We treat src + tgt[1:] as the full timeline
            full_ids = history_ids + current_generated[1:]
            
            used_champions = set()
            current_step_num = 0
            current_phase = "START" # START, STEP, ACTION, CHAMPION
            
            # Parse tokens
            for idx in full_ids:
                if idx in [tokenizer.start_idx, tokenizer.pad_idx, tokenizer.sep_idx, tokenizer.end_idx]:
                    continue
                
                token = tokenizer.id_to_token.get(idx, "")
                
                if token.startswith("STEP_"):
                    current_step_num = int(token.replace("STEP_", ""))
                    current_phase = "STEP"
                elif "_BAN" in token or "_PICK" in token:
                    current_phase = "ACTION"
                else:
                    # Champion
                    current_phase = "CHAMPION"
                    used_champions.add(token)

            # 2. Determine Valid Next Tokens
            valid_tokens = []
            allowed_indices = []
            
            # Logic Transition
            if current_phase == "START" or current_phase == "CHAMPION":
                # Next is STEP_{N+1}
                next_step = current_step_num + 1
                if next_step <= len(draft_order):
                    valid_tokens = [f"STEP_{next_step}"]
                else:
                    allowed_indices = [end_idx] # Draft Over
            
            elif current_phase == "STEP":
                # Next is ACTION for this step
                # draft_order is 0-indexed
                if 0 <= current_step_num - 1 < len(draft_order):
                    rule = draft_order[current_step_num - 1]
                    action_token = f"{rule['side']}_{rule['action']}"
                    valid_tokens = [action_token]
                else:
                    allowed_indices = [end_idx]

            elif current_phase == "ACTION":
                # Next is CHAMPION
                # Any token NOT in structure_tokens and NOT in used_champions
                # This is the "Open" set case
                pass

            # 3. Apply Mask
            mask = torch.full_like(next_token_logits, float('-inf'))
            
            if current_phase == "ACTION":
                # "Open" set case: Allow all champions except used
                # Start with original logits
                mask = next_token_logits.clone()
                
                # Mask out structure/special tokens
                for s_idx in structure_tokens:
                    mask[0, s_idx] = float('-inf')
                    
                # Mask out used champions
                for champ in used_champions:
                    if champ in tokenizer.vocab:
                        mask[0, tokenizer.vocab[champ]] = float('-inf')
                        
            else:
                # "Closed" set case: Only specific tokens allowed
                if not valid_tokens and not allowed_indices:
                     # Fallback
                     allowed_indices = [end_idx]

                # Convert valid_tokens strings to IDs
                for vt in valid_tokens:
                    if vt in tokenizer.vocab:
                        allowed_indices.append(tokenizer.vocab[vt])
                
                if not allowed_indices:
                     allowed_indices = [end_idx]
                
                # Set mask
                tensor_indices = torch.tensor(allowed_indices, device=device)
                # Copy original logits for valid indices
                mask.index_copy_(1, tensor_indices, next_token_logits.index_select(1, tensor_indices))

            # --- END CONSTRAINTS ---

            next_token = mask.argmax(dim=-1)
            
            if next_token.item() == end_idx:
                break
            
            tgt = torch.cat([tgt, next_token.unsqueeze(0)], dim=1)
            
    return tgt[0].tolist()

def decode_sequence(ids, vocab_inv):
    tokens = []
    for idx in ids:
        token = vocab_inv.get(idx, "[UNK]")
        if token in ["[PAD]", "[START]", "[END]", "[SEP]"]:
            continue
        tokens.append(token)
    return tokens

def parse_prediction_tokens(tokens):
    steps = []
    current_step = {}
    
    for token in tokens:
        if token.startswith("STEP_"):
            if "step" in current_step and "champion" in current_step:
                steps.append(current_step)
            current_step = {"step": int(token.replace("STEP_", ""))}
        elif "_PICK" in token or "_BAN" in token:
            parts = token.split("_")
            current_step["team"] = parts[0]
            current_step["action"] = parts[1]
        else:
            current_step["champion"] = token

    if "step" in current_step and "champion" in current_step:
        steps.append(current_step)
    
    return steps

def render_draft_table(full_draft):
    table = Table(title="Full Draft Prediction (History + AI)")
    table.add_column("Step", style="cyan", justify="right")
    table.add_column("Team", style="bold")
    table.add_column("Action", style="dim")
    table.add_column("Champion", style="bold green")
    table.add_column("Source", style="italic")

    # Sort by step
    full_draft.sort(key=lambda x: x["step"])

    for step in full_draft:
        source = step.get("source", "AI")
        source_style = "yellow" if source == "USER" else "blue"
        
        table.add_row(
            str(step["step"]), 
            step.get("team", ""),
            step.get("action", ""),
            step.get("champion", ""),
            f"[{source_style}]{source}[/{source_style}]"
        )
    
    return table

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    # Load Tokenizer
    try:
        tokenizer = LoLTokenizer(args.vocab)
    except Exception as e:
        console.print(f"[red]Error loading tokenizer:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    console.print(f"Loading model on {device}...")
    
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
        console.print("[green]Model loaded successfully.[/green]")
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Interactive Loop
    history = []
    console.print("\n[bold yellow]--- Interactive Draft Mode ---[/bold yellow]")
    console.print("Type a Champion Name to pick/ban.")
    console.print("Type 'predict' at any time to see the full draft.")
    console.print("Type 'exit' to quit.\n")

    for i, step_def in enumerate(DRAFT_ORDER):
        step_num = i + 1
        side = step_def['side']
        action = step_def['action']
        
        # Color coding
        side_color = "cyan" if side == "BLUE" else "red"
        
        while True:
            user_input = console.input(f"[{side_color}]Step {step_num} ({side} {action})[/{side_color}] > ").strip()
            
            if user_input.lower() == 'exit':
                return
                
            if user_input.lower() == 'predict':
                # Run Prediction
                if not history:
                    console.print("[yellow]Empty history. Predicting from start...[/yellow]")
                    
                # Tokenize History
                history_ids = tokenizer.tokenize(history)
                input_ids = [tokenizer.start_idx] + history_ids
                src = torch.tensor(input_ids, dtype=torch.long).unsqueeze(0).to(device)
                
                with console.status("Generating prediction..."):
                    pred_ids = constrained_greedy_decode(
                        model, src, max_len=60, 
                        start_idx=tokenizer.start_idx, end_idx=tokenizer.end_idx, 
                        device=device,
                        tokenizer=tokenizer,
                        draft_order=DRAFT_ORDER
                    )
                
                pred_tokens = decode_sequence(pred_ids, tokenizer.id_to_token)
                
                # Parse and Merge
                predicted_steps = parse_prediction_tokens(pred_tokens)
                
                # Mark sources
                display_history = [{**s, "source": "USER"} for s in history]
                display_prediction = [{**s, "source": "AI"} for s in predicted_steps]
                
                full_draft = display_history + display_prediction
                console.print(render_draft_table(full_draft))
                continue # Ask for same step again

            # Validate Champion
            # Try to match case
            # We construct the expected token to see if it exists
            # Actually, just check if user_input is a champion name in vocab?
            # Vocab contains "Ahri", "Zed", etc.
            # But vocab also contains "STEP_1", "BLUE_BAN".
            # Input should be just Champion Name.
            
            champion_name = user_input
            # Attempt to find case-insensitive match
            match = None
            for token in tokenizer.vocab.keys():
                if token.lower() == champion_name.lower() and "_" not in token and "[" not in token: # Heuristic for champ name
                    match = token
                    break
            
            if match:
                console.print(f"Confirmed: [bold green]{match}[/bold green]")
                history.append({
                    "step": step_num,
                    "team": side,
                    "action": action,
                    "champion": match
                })
                break
            else:
                console.print(f"[red]Champion '{user_input}' not found in vocabulary. Please check spelling.[/red]")
                # List suggestions?
                # For now just loop

    console.print("[bold green]Draft Complete![/bold green]")

if __name__ == "__main__":
    main()
