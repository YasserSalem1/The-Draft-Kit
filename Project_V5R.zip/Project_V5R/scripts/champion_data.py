# Extracted from AI/get_Data.py
CHAMPION_CLASSES_DB = {
    # --- 1. TANKS ---
    "Alistar": ["TANK", "VANGUARD"], "Amumu": ["TANK", "VANGUARD"], "Gragas": ["TANK", "VANGUARD"],
    "Leona": ["TANK", "VANGUARD"], "Malphite": ["TANK", "VANGUARD"], "Maokai": ["TANK", "VANGUARD"],
    "Nautilus": ["TANK", "VANGUARD"], "Nunu & Willump": ["TANK", "VANGUARD"], "Ornn": ["TANK", "VANGUARD"],
    "Rammus": ["TANK", "VANGUARD"], "Rell": ["TANK", "VANGUARD"], "Sejuani": ["TANK", "VANGUARD"],
    "Sion": ["TANK", "VANGUARD"], "Zac": ["TANK", "VANGUARD"],
    "Braum": ["TANK", "WARDEN"], "Galio": ["TANK", "WARDEN"], "K'Sante": ["TANK", "WARDEN"],
    "Poppy": ["TANK", "WARDEN"], "Shen": ["TANK", "WARDEN"], "Tahm Kench": ["TANK", "WARDEN"],
    "Taric": ["TANK", "WARDEN", "CONTROLLER", "ENCHANTER"],

    # --- 2. FIGHTERS ---
    "Aatrox": ["FIGHTER", "JUGGERNAUT"], "Darius": ["FIGHTER", "JUGGERNAUT"], "Dr. Mundo": ["FIGHTER", "JUGGERNAUT"],
    "Garen": ["FIGHTER", "JUGGERNAUT"], "Illaoi": ["FIGHTER", "JUGGERNAUT"], "Mordekaiser": ["FIGHTER", "JUGGERNAUT"],
    "Nasus": ["FIGHTER", "JUGGERNAUT"], "Sett": ["FIGHTER", "JUGGERNAUT"], "Shyvana": ["FIGHTER", "JUGGERNAUT"],
    "Trundle": ["FIGHTER", "JUGGERNAUT"], "Udyr": ["FIGHTER", "JUGGERNAUT"], "Urgot": ["FIGHTER", "JUGGERNAUT"],
    "Volibear": ["FIGHTER", "JUGGERNAUT"], "Yorick": ["FIGHTER", "JUGGERNAUT"],
    "Briar": ["FIGHTER", "DIVER"], "Camille": ["FIGHTER", "DIVER"], "Diana": ["FIGHTER", "DIVER"],
    "Elise": ["FIGHTER", "DIVER"], "Hecarim": ["FIGHTER", "DIVER"], "Irelia": ["FIGHTER", "DIVER"],
    "Jarvan IV": ["FIGHTER", "DIVER"], "Lee Sin": ["FIGHTER", "DIVER"], "Olaf": ["FIGHTER", "DIVER"],
    "Pantheon": ["FIGHTER", "DIVER"], "Rek'Sai": ["FIGHTER", "DIVER"], "Renekton": ["FIGHTER", "DIVER"],
    "Skarner": ["FIGHTER", "DIVER"], "Vi": ["FIGHTER", "DIVER"], "Warwick": ["FIGHTER", "DIVER"],
    "Wukong": ["FIGHTER", "DIVER"], "Xin Zhao": ["FIGHTER", "DIVER"],

    # --- 3. SLAYERS ---
    "Akali": ["SLAYER", "ASSASSIN"], "Akshan": ["SLAYER", "ASSASSIN"], "Ekko": ["SLAYER", "ASSASSIN"],
    "Evelynn": ["SLAYER", "ASSASSIN"], "Fizz": ["SLAYER", "ASSASSIN"], "Kassadin": ["SLAYER", "ASSASSIN"],
    "Katarina": ["SLAYER", "ASSASSIN"], "Kha'Zix": ["SLAYER", "ASSASSIN"], "Naafiri": ["SLAYER", "ASSASSIN"],
    "Nocturne": ["SLAYER", "ASSASSIN"], "Pyke": ["SLAYER", "ASSASSIN", "CONTROLLER", "CATCHER"],
    "Qiyana": ["SLAYER", "ASSASSIN"], "Rengar": ["SLAYER", "ASSASSIN"], "Shaco": ["SLAYER", "ASSASSIN"],
    "Talon": ["SLAYER", "ASSASSIN"], "Zed": ["SLAYER", "ASSASSIN"],
    "Bel'Veth": ["SLAYER", "SKIRMISHER"], "Fiora": ["SLAYER", "SKIRMISHER"], "Gwen": ["SLAYER", "SKIRMISHER"],
    "Jax": ["SLAYER", "SKIRMISHER"], "Kayn": ["SLAYER", "SKIRMISHER"], "Kled": ["SLAYER", "SKIRMISHER"],
    "Lillia": ["SLAYER", "SKIRMISHER"], "Master Yi": ["SLAYER", "SKIRMISHER"], "Nilah": ["SLAYER", "SKIRMISHER"],
    "Riven": ["SLAYER", "SKIRMISHER"], "Sylas": ["SLAYER", "SKIRMISHER", "MAGE", "BURST"],
    "Tryndamere": ["SLAYER", "SKIRMISHER"], "Viego": ["SLAYER", "SKIRMISHER"], "Yasuo": ["SLAYER", "SKIRMISHER"],
    "Yone": ["SLAYER", "SKIRMISHER"],

    # --- 4. MAGES ---
    "Ahri": ["MAGE", "BURST"], "Annie": ["MAGE", "BURST"], "Brand": ["MAGE", "BURST"],
    "LeBlanc": ["MAGE", "BURST"], "Lissandra": ["MAGE", "BURST"], "Lux": ["MAGE", "BURST", "ARTILLERY"],
    "Neeko": ["MAGE", "BURST", "CONTROLLER", "CATCHER"],
    "Orianna": ["MAGE", "BURST"], "Seraphine": ["MAGE", "BURST"], "Syndra": ["MAGE", "BURST"],
    "Twisted Fate": ["MAGE", "BURST"], "Veigar": ["MAGE", "BURST"], "Vex": ["MAGE", "BURST"],
    "Zoe": ["MAGE", "BURST"],
    "Anivia": ["MAGE", "BATTLE_MAGE"], "Aurelion Sol": ["MAGE", "BATTLE_MAGE"], "Cassiopeia": ["MAGE", "BATTLE_MAGE"],
    "Karthus": ["MAGE", "BATTLE_MAGE"], "Malzahar": ["MAGE", "BATTLE_MAGE"], "Rumble": ["MAGE", "BATTLE_MAGE"],
    "Ryze": ["MAGE", "BATTLE_MAGE"], "Swain": ["MAGE", "BATTLE_MAGE"], "Taliyah": ["MAGE", "BATTLE_MAGE"],
    "Viktor": ["MAGE", "BATTLE_MAGE"], "Vladimir": ["MAGE", "BATTLE_MAGE"],
    "Hwei": ["MAGE", "ARTILLERY"], "Jayce": ["MAGE", "ARTILLERY"], "Vel'Koz": ["MAGE", "ARTILLERY"],
    "Xerath": ["MAGE", "ARTILLERY"], "Ziggs": ["MAGE", "ARTILLERY"],

    # --- 5. CONTROLLERS ---
    "Janna": ["CONTROLLER", "ENCHANTER"], "Karma": ["CONTROLLER", "ENCHANTER"], "Lulu": ["CONTROLLER", "ENCHANTER"],
    "Milio": ["CONTROLLER", "ENCHANTER"], "Nami": ["CONTROLLER", "ENCHANTER"], "Renata Glasc": ["CONTROLLER", "ENCHANTER"],
    "Senna": ["CONTROLLER", "ENCHANTER", "MARKSMAN"],
    "Sona": ["CONTROLLER", "ENCHANTER"], "Soraka": ["CONTROLLER", "ENCHANTER"], "Yuumi": ["CONTROLLER", "ENCHANTER"],
    "Zilean": ["CONTROLLER", "ENCHANTER"],
    "Bard": ["CONTROLLER", "CATCHER"], "Blitzcrank": ["CONTROLLER", "CATCHER"], "Ivern": ["CONTROLLER", "CATCHER"],
    "Jhin": ["CONTROLLER", "CATCHER", "MARKSMAN"],
    "Morgana": ["CONTROLLER", "CATCHER"], "Rakan": ["CONTROLLER", "CATCHER"], "Thresh": ["CONTROLLER", "CATCHER"],
    "Zyra": ["CONTROLLER", "CATCHER"],

    # --- 6. MARKSMEN (ADC) ---
    "Aphelios": ["MARKSMAN"], "Ashe": ["MARKSMAN"], "Caitlyn": ["MARKSMAN"], "Corki": ["MARKSMAN"],
    "Draven": ["MARKSMAN"], "Ezreal": ["MARKSMAN"], "Jinx": ["MARKSMAN"], "Kai'Sa": ["MARKSMAN"],
    "Kalista": ["MARKSMAN"], "Kog'Maw": ["MARKSMAN"], "Lucian": ["MARKSMAN"], "Miss Fortune": ["MARKSMAN"],
    "Samira": ["MARKSMAN"], "Sivir": ["MARKSMAN"], "Smolder": ["MARKSMAN"], "Tristana": ["MARKSMAN"],
    "Twitch": ["MARKSMAN"], "Varus": ["MARKSMAN"], "Vayne": ["MARKSMAN"], "Xayah": ["MARKSMAN"],
    "Zeri": ["MARKSMAN"],

    # --- 7. SPECIALISTS ---
    "Azir": ["SPECIALIST"], "Cho'Gath": ["SPECIALIST"], "Fiddlesticks": ["SPECIALIST"], "Gangplank": ["SPECIALIST"],
    "Gnar": ["SPECIALIST"], "Graves": ["SPECIALIST"], "Heimerdinger": ["SPECIALIST"], "Kayle": ["SPECIALIST"],
    "Kennen": ["SPECIALIST"], "Nidalee": ["SPECIALIST"], "Quinn": ["SPECIALIST"], "Singed": ["SPECIALIST"],
    "Teemo": ["SPECIALIST"]
}

def get_champion_role(champion_name):
    """
    Infers a likely role based on champion class.
    This is a heuristic as real roles depend on meta.
    """
    # Specific overrides for accuracy
    overrides = {
        "Alistar": "SUPPORT", "Braum": "SUPPORT", "Leona": "SUPPORT", "Nautilus": "SUPPORT", "Rell": "SUPPORT", 
        "Taric": "SUPPORT", "Tahm Kench": "SUPPORT", "Rakan": "SUPPORT", "Pyke": "SUPPORT",
        "Amumu": "JUNGLE", "Sejuani": "JUNGLE", "Zac": "JUNGLE", "Nunu & Willump": "JUNGLE", "Rammus": "JUNGLE",
        "Master Yi": "JUNGLE", "Bel'Veth": "JUNGLE", "Viego": "JUNGLE", "Lillia": "JUNGLE", "Kindred": "JUNGLE", 
        "Graves": "JUNGLE", "Nidalee": "JUNGLE", "Elise": "JUNGLE", "Evelynn": "JUNGLE", "Kha'Zix": "JUNGLE", "Rengar": "JUNGLE", "Nocturne": "JUNGLE",
        "Darius": "TOP", "Garen": "TOP", "Sett": "TOP", "Mordekaiser": "TOP", "Camille": "TOP", "Fiora": "TOP", "Riven": "TOP", "Renekton": "TOP",
        "Ahri": "MID", "Syndra": "MID", "Orianna": "MID", "Zed": "MID", "Yasuo": "MID", "Yone": "MID"
    }
    
    if champion_name in overrides:
        return overrides[champion_name]

    classes = CHAMPION_CLASSES_DB.get(champion_name, [])
    
    if "MARKSMAN" in classes: return "BOT"
    if "ENCHANTER" in classes or "CATCHER" in classes: return "SUPPORT" # Catchers like Thresh/Blitz
    if "MAGE" in classes: return "MID"
    if "ASSASSIN" in classes: return "MID" # OR JUNGLE
    if "JUGGERNAUT" in classes: return "TOP"
    if "VANGUARD" in classes: return "JUNGLE" # Or SUP/TOP (Tanks)
    if "DIVER" in classes: return "JUNGLE" # Or TOP
    if "SKIRMISHER" in classes: return "TOP" # Or JUNGLE (Yi/Viego)
    
    return "UNKNOWN"
