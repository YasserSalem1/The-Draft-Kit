import argparse
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from tqdm import tqdm
from pathlib import Path

# Add project root to path for imports if needed, though we will assume running from root
import sys
sys.path.append(str(Path(__file__).parent.parent))

from scripts.dataset import LoLDraftDataset
from scripts.model import LoLTransformer

def calculate_accuracy(logits, targets, k=1, pad_idx=0):
    # logits: [Batch*Seq, Vocab]
    # targets: [Batch*Seq]
    
    # Filter out pads
    mask = targets != pad_idx
    logits = logits[mask]
    targets = targets[mask]
    
    if len(targets) == 0:
        return 0.0
        
    _, pred = logits.topk(k, dim=1, largest=True, sorted=True)
    # pred: [N, k]
    targets = targets.view(-1, 1).expand_as(pred)
    
    correct = pred.eq(targets).float()
    return correct.sum().item() / len(targets)

def train(args):
    device = torch.device("cuda" if torch.cuda.is_available() and args.gpu else "cpu")
    print(f"Using device: {device}")
    
    # 1. Load Data
    print("Loading datasets...")
    train_ds = LoLDraftDataset(args.train_path, args.vocab_path, max_seq_len=150)
    val_ds = LoLDraftDataset(args.val_path, args.vocab_path, max_seq_len=150)
    
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0)
    
    # 2. Model
    model = LoLTransformer(
        vocab_size=len(train_ds.vocab),
        d_model=256,
        nhead=8,
        num_encoder_layers=6,
        num_decoder_layers=6,
        dim_feedforward=1024,
        dropout=0.1,
        pad_idx=train_ds.pad_idx
    ).to(device)
    
    # 3. Optimizer & Scheduler
    optimizer = optim.AdamW(model.parameters(), lr=args.lr)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    optimizer = optim.AdamW(model.parameters(), lr=args.lr)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
    # Label Smoothing improves "Recommendation" quality by preventing overconfidence
    criterion = nn.CrossEntropyLoss(ignore_index=train_ds.pad_idx, label_smoothing=0.1)
    
    best_val_loss = float('inf')
    os.makedirs(args.checkpoint_dir, exist_ok=True)
    
    for epoch in range(args.epochs):
        model.train()
        train_loss = 0
        train_acc_1 = 0
        train_steps = 0
        
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{args.epochs}")
        for batch in pbar:
            src = batch['input_tokens'].to(device)
            tgt = batch['target_tokens'].to(device)
            
            tgt_input = tgt[:, :-1]
            tgt_output = tgt[:, 1:]
            
            optimizer.zero_grad()
            logits = model(src, tgt_input)
            
            # Reshape for loss
            flat_logits = logits.reshape(-1, logits.size(-1))
            flat_tgt = tgt_output.reshape(-1)
            
            loss = criterion(flat_logits, flat_tgt)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item()
            train_acc_1 += calculate_accuracy(flat_logits, flat_tgt, k=1, pad_idx=train_ds.pad_idx)
            train_steps += 1
            
            pbar.set_postfix(loss=loss.item())
            
        scheduler.step()
        
        # Validation
        model.eval()
        val_loss = 0
        val_acc_1 = 0
        val_acc_5 = 0
        val_steps = 0
        
        with torch.no_grad():
            for batch in val_loader:
                src = batch['input_tokens'].to(device)
                tgt = batch['target_tokens'].to(device)
                
                tgt_input = tgt[:, :-1]
                tgt_output = tgt[:, 1:]
                
                logits = model(src, tgt_input)
                flat_logits = logits.reshape(-1, logits.size(-1))
                flat_tgt = tgt_output.reshape(-1)
                
                loss = criterion(flat_logits, flat_tgt)
                
                val_loss += loss.item()
                val_acc_1 += calculate_accuracy(flat_logits, flat_tgt, k=1, pad_idx=train_ds.pad_idx)
                val_acc_5 += calculate_accuracy(flat_logits, flat_tgt, k=5, pad_idx=train_ds.pad_idx)
                val_steps += 1
                
        avg_train_loss = train_loss / train_steps
        avg_train_acc = train_acc_1 / train_steps
        avg_val_loss = val_loss / val_steps
        avg_val_acc1 = val_acc_1 / val_steps
        avg_val_acc5 = val_acc_5 / val_steps
        
        print(f"Epoch {epoch+1}: Train Loss={avg_train_loss:.4f}, Acc={avg_train_acc:.4f} | Val Loss={avg_val_loss:.4f}, Top-1={avg_val_acc1:.4f}, Top-5={avg_val_acc5:.4f}")
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
            save_path = os.path.join(args.checkpoint_dir, "best_model.pt")
            torch.save(model.state_dict(), save_path)
            print(f"Saved Best Model to {save_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--train_path", default="data/processed/train.parquet")
    parser.add_argument("--val_path", default="data/processed/val.parquet")
    parser.add_argument("--vocab_path", default="data/metadata/vocab.json")
    parser.add_argument("--checkpoint_dir", default="checkpoints")
    parser.add_argument("--batch_size", type=int, default=128)
    parser.add_argument("--epochs", type=int, default=50)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--gpu", action="store_true", help="Use GPU")
    
    args = parser.parse_args()
    train(args)
