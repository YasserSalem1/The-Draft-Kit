import sys
import torch
import argparse
import random
import json
import numpy as np
from pathlib import Path
from rich.console import Console
from rich.table import Table
from tqdm import tqdm

# Add project root to sys.path
current_dir = Path(__file__).parent
if str(current_dir.parent) not in sys.path:
    sys.path.append(str(current_dir.parent))

from scripts.dataset import LoLDraftDataset, LoLTokenizer
from scripts.model import LoLTransformer

console = Console()

# Standard Draft Order (referenced if needed for masking, but for simple Top-K we can just check champion probabilities)
DRAFT_ORDER = [
    # ... (Standard list, same as other files) ...
]

def get_next_token_probs(model, history_ids, device, tokenizer):
    """
    Returns probabilities for the next token given history.
    """
    model.eval()
    
    # Encoder Input
    src = torch.tensor([tokenizer.start_idx] + history_ids, dtype=torch.long, device=device).unsqueeze(0)
    
    # Decoder Input: Start with [START]
    # We want to predict the very first token of the "Next Step" response.
    # WAIT. Standard Transformer Seq2Seq: 
    # If we want to predict "Next Token", we feed the decoder what we have generated so far.
    # But here we want to predict the CHAMPION of the next step.
    # The next step starts with [STEP_X], then [ACTION], then [ROLE], then [CHAMPION].
    
    # This is tricky because the model predicts [STEP] first.
    # If we want "Top-K Champions", we need to simulate the generation UNTIL the champion token.
    # OR: We just look at the 'Champion' probability at the moment it is supposed to be predicted?
    # This requires forcing the prefix (STEP -> ACTION -> ROLE).
    
    # BETTER APPROACH:
    # 1. Feed Encoder = History.
    # 2. Feed Decoder (Teacher Force) = [START, STEP_X, ACTION, ROLE].
    # 3. Predict Next Token -> This SHOULD be the Champion.
    # 4. Check Top-K of this prediction against Ground Truth Champion.
    
    # To do this, we need to know the correct STEP, ACTION, and ROLE for the upcoming step.
    # We get this from Ground Truth.
    # This evaluates: "Given we know it's Blue Pick Top, what Champ will they pick?"
    # This isolates Champion Selection accuracy from structural/role prediction accuracy.
    # This is the most fair "Recommender" metric.
    
    return None # Placeholder

def calculate_top_k(model, device, tokenizer, match, k_list=[1, 3, 5, 10]):
    """
    Evaluates Top-K accuracy for a single match.
    """
    full_gt_dicts = json.loads(match['remaining_sequence'])
    hist_dicts = json.loads(match['draft_history'])
    full_steps = hist_dicts + full_gt_dicts
    full_steps.sort(key=lambda x: int(x.get('step', 0)))
    
    # We need strictly 20 steps
    if len(full_steps) > 20: full_steps = full_steps[:20]
    
    hits = {k: 0 for k in k_list}
    total = 0
    
    accumulated_history_ids = []
    
    for step_obj in full_steps:
        # Ground Truths
        gt_champ = step_obj.get('champion')
        if not gt_champ or gt_champ not in tokenizer.vocab:
             # Skip unknown/weird data
             # Update history and continue
             step_tokens = tokenizer.tokenize([step_obj])
             accumulated_history_ids.extend(step_tokens)
             continue
             
        # Prepare Context for Prediction
        # 1. Encoder = History
        src = torch.tensor([tokenizer.start_idx] + accumulated_history_ids, dtype=torch.long, device=device).unsqueeze(0)
        
        # 2. Prepare Decoder Prefix (Teacher Force structure)
        # We need tokens for: [START] + [STEP_X] + [ACTION] + [ROLE]
        # We can extract these from the Ground Truth object accurately.
        # Note: dataset.tokenize() gives us the full sequence [STEP, ACTION, ROLE, CHAMP, CLASS...].
        # We can just take the first 3 tokens of the tokenized step!
        
        full_step_tokens = tokenizer.tokenize([step_obj])
        # Expected structure: STEP, ACTION, ROLE, CHAMPION ...
        # So indices 0, 1, 2 are prefix. Index 3 is Champion.
        
        if len(full_step_tokens) < 4:
             # Weird step, skip
             accumulated_history_ids.extend(full_step_tokens)
             continue
        
        prefix_ids = [tokenizer.start_idx] + full_step_tokens[:3] # [START, STEP, ACT, ROLE]
        gt_champ_id = full_step_tokens[3]
        
        # Verify gt_champ_id is actually a champion?
        # tokenizer.id_to_token[gt_champ_id] should not be ROLE/STEP/CLASS/ACTION
        
        # Run Model to predict index 4 (Champion)
        # Decoder Input = prefix_ids
        tgt = torch.tensor(prefix_ids, dtype=torch.long, device=device).unsqueeze(0)
        
        with torch.no_grad():
            output = model(src, tgt)
            # Logits for the NEXT token (at the end)
            next_token_logits = output[:, -1, :]
            
            # Mask out non-champions to be fair?
            # A recommender usually only suggests valid items (Champions).
            # So we should mask out STEP, ROLE, ACTION, CLASS, START, END, PAD.
            mask = next_token_logits.clone()
            for t, idx in tokenizer.vocab.items():
                if t.startswith("STEP_") or "_BAN" in t or "_PICK" in t or t.startswith("ROLE_") or t.startswith("CLASS_") or t.startswith("[") or t == "UNKNOWN":
                    mask[0, idx] = float('-inf')
            
            # Get Top-K
            # max_k = max(k_list)
            # probs = torch.softmax(mask, dim=-1)
            # top_k_probs, top_k_indices = torch.topk(probs, max_k)
            # Actually just argsort descending
            
            sorted_logits, sorted_indices = torch.sort(mask, descending=True)
            sorted_indices = sorted_indices[0].tolist() # List of IDs
            
            # Check Rank
            if gt_champ_id in sorted_indices:
                rank = sorted_indices.index(gt_champ_id) + 1 # 1-based rank
                for k in k_list:
                    if rank <= k:
                        hits[k] += 1
            
            total += 1
            
        # Update History
        accumulated_history_ids.extend(full_step_tokens)
        
    return hits, total

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, default="AI/checkpoints/best_model.pt")
    parser.add_argument("--data", type=str, default="AI/data/processed/test.parquet")
    parser.add_argument("--vocab", type=str, default="AI/data/metadata/vocab.json")
    parser.add_argument("--device", type=str, default="cpu")
    args = parser.parse_args()

    # Load Tokenizer & Dataset
    try:
        ds = LoLDraftDataset(args.data, args.vocab)
        tokenizer = ds.tokenizer
    except Exception as e:
        console.print(f"[red]Error loading data:[/red] {e}")
        return

    # Load Model
    device = torch.device(args.device)
    model = LoLTransformer(
        vocab_size=len(tokenizer.vocab),
        d_model=256, nhead=8, num_encoder_layers=6, num_decoder_layers=6,
        dim_feedforward=1024, dropout=0.1, max_seq_len=150, pad_idx=tokenizer.pad_idx
    ).to(device)

    if Path(args.checkpoint).exists():
        checkpoint = torch.load(args.checkpoint, map_location=device)
        state_dict = checkpoint['model_state_dict'] if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint else checkpoint
        model.load_state_dict(state_dict)
    else:
        console.print(f"[red]Checkpoint not found at {args.checkpoint}[/red]")
        return

    # Iterate over ALL unique matches in test set
    unique_matches = ds.data['match_id'].unique()
    console.print(f"\n[bold green]Calculating Forecast Accuracy on {len(unique_matches)} Test Matches...[/bold green]")
    
    global_hits = {1: 0, 3: 0, 5: 0, 10: 0}
    global_total = 0
    k_list = [1, 3, 5, 10]

    for match_id in tqdm(unique_matches):
        match_rows = ds.data[ds.data['match_id'] == match_id].sort_values('sample_id')
        if len(match_rows) == 0: continue
        
        # We essentially reconstruct the match from the first sample (which has full future)
        # But we only need ONE row to get the full match data structure.
        row = match_rows.iloc[0]
        
        hits, count = calculate_top_k(model, device, tokenizer, row, k_list)
        
        for k in k_list:
            global_hits[k] += hits[k]
        global_total += count

    # Report
    table = Table(title="Next Champion Prediction Accuracy (Test Set)")
    table.add_column("Metric", style="bold cyan")
    table.add_column("Accuracy", style="bold green")
    table.add_column("Hits/Total", style="dim")
    
    if global_total > 0:
        for k in k_list:
            acc = global_hits[k] / global_total
            table.add_row(f"Top-{k} Accuracy", f"{acc*100:.2f}%", f"{global_hits[k]}/{global_total}")
    else:
        console.print("[red]No valid steps evaluated.[/red]")

    console.print(table)
    console.print("\n[dim]Note: This evaluates 'Given History + Step/Action/Role -> Predict Champion'.[/dim]")

if __name__ == "__main__":
    main()
